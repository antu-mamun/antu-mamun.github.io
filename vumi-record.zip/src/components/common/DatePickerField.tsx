"use client"

import * as React from "react"
import { format, parse, isValid } from "date-fns"
import { CalendarIcon } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

interface DatePickerFieldProps {
  value: string        // stored as DD/MM/YYYY
  onChange: (value: string) => void
  placeholder?: string
  className?: string
}

export function DatePickerField({ value, onChange, placeholder = "তারিখ নির্বাচন করুন", className }: DatePickerFieldProps) {
  const [open, setOpen] = React.useState(false)

  // Parse DD/MM/YYYY string → Date object
  const parseValue = (v: string): Date | undefined => {
    if (!v) return undefined
    const parsed = parse(v, "dd/MM/yyyy", new Date())
    return isValid(parsed) ? parsed : undefined
  }

  const selected = parseValue(value)

  const handleSelect = (date: Date | undefined) => {
    if (date) {
      onChange(format(date, "dd/MM/yyyy"))
    } else {
      onChange("")
    }
    setOpen(false)
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "h-12 w-full justify-start text-left font-normal border-slate-300",
            !value && "text-muted-foreground",
            className
          )}
        >
          <CalendarIcon className="mr-2 h-4 w-4 text-orange-500 shrink-0" />
          {value ? value : <span>{placeholder}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={selected}
          onSelect={handleSelect}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  )
}
