'use client';

export function DynamicYear() {
    const currentYear = new Date().getFullYear();

    // Convert to Bengali numerals
    const bengaliNumerals = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    const bengaliYear = currentYear.toString().split('').map(digit => bengaliNumerals[parseInt(digit)]).join('');

    return <span>{bengaliYear}</span>;
}
