'use client';

import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { deleteAbandoned } from '@/actions/abandoned';
import { useRouter } from 'next/navigation';
import { Pencil, Trash2, FileText } from 'lucide-react';

type PersonalInfo = {
  name: string;
  parentName: string;
  address: string;
  mobile: string;
};

const parsePersonalInfo = (raw: string | undefined): PersonalInfo[] => {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parsed;
  } catch {
    // ignore
  }
  return [];
};

const AbandonedPropertyList = ({
  abandonedPropertyList,
  onEdit,
}: {
  abandonedPropertyList: Record<string, any>[];
  onEdit?: (abandoned: Record<string, any>) => void;
}) => {
  const router = useRouter();

  const handleDelete = async (id: string) => {
    if (window.confirm('আপনি কি নিশ্চিতভাবে মুছে ফেলতে চান?')) {
      await deleteAbandoned(id);
      router.refresh();
    }
  };

  const totalCols = onEdit ? 16 : 15;

  return (
    <div className="w-full overflow-x-auto rounded-md mt-0 [contain:inline-size]">
      
      <span className="text-lg text-gray-600 mb-2 block">জেলাঃ চাঁপাইনবাবগঞ্জ, উপজেলাঃ চাঁপাইনবাবগঞ্জ</span>
      <span className="text-md text-gray-500 mb-2 block">মোট {abandonedPropertyList.length} টি অর্পিত সম্পত্তি</span>
      <Table>
        <TableHeader className="bg-gradient-to-r from-green-100/60 to-emerald-100/60">
          <TableRow>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              ক্রমিক নং
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              কেস নথি নং
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              তালিকাভুক্তির তারিখ
            </TableHead>
            <TableHead colSpan={8} className="border text-center border-green-700">
              তফসিল
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              সরকার কর্তৃক দখলের তারিখ
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              মূল মালিকের তথ্য
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              লীজ গ্রহীতার তথ্য
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              সর্বশেষ লীজ প্রদান / নবায়নের সাল
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              মামলা সংক্রান্ত তথ্য
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700 whitespace-pre-line">
              প্রতিবেদন
            </TableHead>
            <TableHead rowSpan={2} className="border text-center border-green-700  whitespace-pre-line">
              মন্তব্য
            </TableHead>
            {onEdit && (
              <TableHead rowSpan={2} className="border text-center border-green-700">
                অ্যাকশন
              </TableHead>
            )}
          </TableRow>
          <TableRow>
            <TableHead className="border text-center border-green-700 whitespace-pre-line">মৌজা</TableHead>
            <TableHead className="border text-center border-green-700 whitespace-pre-line">জে.এল. নং</TableHead>
            <TableHead className="border text-center border-green-700 whitespace-pre-line">সাবেক SA খতিয়ান নং</TableHead>
            <TableHead className="border text-center border-green-700 whitespace-pre-line">সাবেক SA দাগ নং</TableHead>
            <TableHead className="border text-center border-green-700 whitespace-pre-line">হাল খতিয়ান নং</TableHead>
            <TableHead className="border text-center border-green-700 whitespace-pre-line">হাল দাগ নং</TableHead>
            <TableHead className="border text-center border-green-700 whitespace-pre-line">পরিমাণ (একর)</TableHead>
            <TableHead className="border text-center border-green-700 whitespace-pre-line">শ্রেণী</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody className="bg-white">
          {abandonedPropertyList.length === 0 ? (
            <TableRow>
              <TableCell colSpan={totalCols} className="text-center py-8 text-gray-500">
                কোনো তথ্য পাওয়া যায়নি
              </TableCell>
            </TableRow>
          ) : (
            abandonedPropertyList.map((abandoned, index) => {
              const originalOwners = parsePersonalInfo(abandoned.originalOwnerInfo);
              const lessees = parsePersonalInfo(abandoned.lesseeInfo);
              return (
                <TableRow key={abandoned.id}>
                  <TableCell className="border text-center border-green-700">{index + 1}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.caseNo}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.inclusionDate}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.mouja?.name || ''}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.mouja?.jlNo || ''}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.sabakSaKhotianNo}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.sabakSaDagNo}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.halKhotianNo}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.halDagNo}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.dagLandSize}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.category || ''}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.governmentPossessionDate || ''}</TableCell>
                  <TableCell className="border text-center border-green-700">
                    {originalOwners.length > 0 ? originalOwners.map((person, i) => (
                      <div key={i} className={`mb-2 ${i > 0 ? 'border-t pt-2' : ''}`}>
                        <div>নাম- {person.name}</div>
                        <div className="text-xs">পিতা- {person.parentName}</div>
                        <div className="text-xs">ঠিকানা- {person.address}</div>
                        <div className="text-xs">মোবাইল- {person.mobile}</div>
                      </div>
                    )) : <span className="text-slate-400 text-xs">-</span>}
                  </TableCell>
                  <TableCell className="border text-center border-green-700">
                    {lessees.length > 0 ? lessees.map((person, i) => (
                      <div key={i} className={`mb-2 ${i > 0 ? 'border-t pt-2' : ''}`}>
                        <div>নাম- {person.name}</div>
                        <div className="text-xs">পিতা- {person.parentName}</div>
                        <div className="text-xs">ঠিকানা- {person.address}</div>
                        <div className="text-xs">মোবাইল- {person.mobile}</div>
                      </div>
                    )) : <span className="text-slate-400 text-xs">-</span>}
                  </TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.lastRenewalYear || ''}</TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.caseInfo || ''}</TableCell>
                  <TableCell className="border text-center border-green-700">
                    {abandoned.reportFilePath ? (
                      <a
                        href={`/api/files/preview?path=${encodeURIComponent(abandoned.reportFilePath)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-1 text-blue-600 hover:text-blue-800"
                        title={abandoned.reportOriginalName || 'প্রতিবেদন'}
                      >
                        <FileText className="w-4 h-4 shrink-0" />
                        <span className="text-xs max-w-[80px] truncate">{abandoned.reportOriginalName || 'দেখুন'}</span>
                      </a>
                    ) : (
                      <span className="text-slate-400 text-xs">নেই</span>
                    )}
                  </TableCell>
                  <TableCell className="border text-center border-green-700">{abandoned.comment || ''}</TableCell>
                  {onEdit && (
                    <TableCell className="border text-center border-green-700">
                      <div className="flex flex-col items-center justify-center gap-2">
                        <Button
                          size="icon"
                          variant="outline"
                          className="text-green-700 border-green-700"
                          onClick={() => onEdit(abandoned)}
                          title="এডিট করুন"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="destructive"
                          onClick={() => handleDelete(abandoned.id)}
                          title="ডিলিট করুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              );
            })
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default AbandonedPropertyList;

