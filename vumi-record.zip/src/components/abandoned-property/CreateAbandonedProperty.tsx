'use client';

import React, { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { MoujaSelect } from '../mouja/MoujaSelect';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Label } from '../ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Mouja } from '@/generated/prisma';
import { createAbandoned, updateAbandoned } from '@/actions/abandoned';
import { uploadFile } from '@/actions/files';
import PersonalInfoManager, { PersonalInfo } from '../nothi/PersonalInfoManager';
import { DatePickerField } from '../common/DatePickerField';
import {
  RotateCcw,
  Save,
  Pencil,
  MapPin,
  Hash,
  Scale,
  Calendar,
  User,
  MessageSquare,
  FileText,
  Building2,
  CheckCircle2,
  Sparkles,
  Upload,
  Loader2,
} from 'lucide-react';

type EditData = {
  id: string;
  moujaId: string;
  caseNo: string;
  inclusionDate: string;
  sabakSaKhotianNo: string;
  sabakSaDagNo: string;
  halKhotianNo: string;
  halDagNo: string;
  dagLandSize: string;
  category?: string;
  lastRenewalYear?: string;
  originalOwnerInfo?: PersonalInfo[];
  lesseeInfo?: PersonalInfo[];
  caseInfo?: string;
  governmentPossessionDate?: string;
  reportFilePath?: string;
  reportOriginalName?: string;
  comment?: string;
};

const emptyPerson = (): PersonalInfo => ({ name: '', parentName: '', address: '', mobile: '' });

const parsePersonalInfo = (raw: string | PersonalInfo[] | undefined): PersonalInfo[] => {
  if (!raw) return [emptyPerson()];
  if (Array.isArray(raw)) return raw.length > 0 ? raw : [emptyPerson()];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : [emptyPerson()];
  } catch {
    return [emptyPerson()];
  }
};

const CreateAbandonedProperty = ({
  mouzaData,
  editData,
  onFinishEdit,
}: {
  mouzaData: Mouja[];
  editData?: Record<string, any> | null;
  onFinishEdit?: () => void;
}) => {
  const router = useRouter();

  // Required fields
  const [moujaId, setMoujaId] = useState('');
  const [caseNo, setCaseNo] = useState('');
  const [inclusionDate, setInclusionDate] = useState('');
  const [sabakSaKhotianNo, setSabakSaKhotianNo] = useState('');
  const [sabakSaDagNo, setSabakSaDagNo] = useState('');
  const [halKhotianNo, setHalKhotianNo] = useState('');
  const [halDagNo, setHalDagNo] = useState('');
  const [dagLandSize, setDagLandSize] = useState('');

  // Optional fields
  const [category, setCategory] = useState('');
  const [lastRenewalYear, setLastRenewalYear] = useState('');
  const [originalOwnerInfo, setOriginalOwnerInfo] = useState<PersonalInfo[]>([emptyPerson()]);
  const [lesseeInfo, setLesseeInfo] = useState<PersonalInfo[]>([emptyPerson()]);
  const [caseInfo, setCaseInfo] = useState('');
  const [governmentPossessionDate, setGovernmentPossessionDate] = useState('');
  const [reportFilePath, setReportFilePath] = useState('');
  const [reportOriginalName, setReportOriginalName] = useState('');
  const [comment, setComment] = useState('');

  // UI state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [errors, setErrors] = useState<Record<string, boolean>>({});

  // Refs for scroll-to-error
  const moujaRef = useRef<HTMLDivElement>(null);
  const caseNoRef = useRef<HTMLDivElement>(null);
  const inclusionDateRef = useRef<HTMLDivElement>(null);
  const sabakSaKhotianNoRef = useRef<HTMLDivElement>(null);
  const sabakSaDagNoRef = useRef<HTMLDivElement>(null);
  const halKhotianNoRef = useRef<HTMLDivElement>(null);
  const halDagNoRef = useRef<HTMLDivElement>(null);
  const dagLandSizeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (editData) {
      setEditingId(editData.id);
      setMoujaId(editData.moujaId || '');
      setCaseNo(editData.caseNo || '');
      setInclusionDate(editData.inclusionDate || '');
      setSabakSaKhotianNo(editData.sabakSaKhotianNo || '');
      setSabakSaDagNo(editData.sabakSaDagNo || '');
      setHalKhotianNo(editData.halKhotianNo || '');
      setHalDagNo(editData.halDagNo || '');
      setDagLandSize(editData.dagLandSize || '');
      setCategory(editData.category || '');
      setLastRenewalYear(editData.lastRenewalYear || '');
      setOriginalOwnerInfo(parsePersonalInfo(editData.originalOwnerInfo));
      setLesseeInfo(parsePersonalInfo(editData.lesseeInfo));
      setCaseInfo(editData.caseInfo || '');
      setGovernmentPossessionDate(editData.governmentPossessionDate || '');
      setReportFilePath(editData.reportFilePath || '');
      setReportOriginalName(editData.reportOriginalName || '');
      setComment(editData.comment || '');
    } else {
      resetForm();
    }
  }, [editData]);

  const resetForm = () => {
    setEditingId(null);
    setMoujaId('');
    setCaseNo('');
    setInclusionDate('');
    setSabakSaKhotianNo('');
    setSabakSaDagNo('');
    setHalKhotianNo('');
    setHalDagNo('');
    setDagLandSize('');
    setCategory('');
    setLastRenewalYear('');
    setOriginalOwnerInfo([emptyPerson()]);
    setLesseeInfo([emptyPerson()]);
    setCaseInfo('');
    setGovernmentPossessionDate('');
    setReportFilePath('');
    setReportOriginalName('');
    setComment('');
    setErrors({});
    if (onFinishEdit) onFinishEdit();
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, boolean> = {};
    if (!moujaId) newErrors.moujaId = true;
    if (!caseNo.trim()) newErrors.caseNo = true;
    if (!inclusionDate.trim()) newErrors.inclusionDate = true;
    if (!sabakSaKhotianNo.trim()) newErrors.sabakSaKhotianNo = true;
    if (!sabakSaDagNo.trim()) newErrors.sabakSaDagNo = true;
    if (!halKhotianNo.trim()) newErrors.halKhotianNo = true;
    if (!halDagNo.trim()) newErrors.halDagNo = true;
    if (!dagLandSize.trim()) newErrors.dagLandSize = true;

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      const firstRefMap: Record<string, React.RefObject<HTMLDivElement | null>> = {
        moujaId: moujaRef,
        caseNo: caseNoRef,
        inclusionDate: inclusionDateRef,
        sabakSaKhotianNo: sabakSaKhotianNoRef,
        sabakSaDagNo: sabakSaDagNoRef,
        halKhotianNo: halKhotianNoRef,
        halDagNo: halDagNoRef,
        dagLandSize: dagLandSizeRef,
      };
      for (const key of Object.keys(newErrors)) {
        const ref = firstRefMap[key];
        if (ref?.current) {
          ref.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
          break;
        }
      }
      return false;
    }
    return true;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      const nameWithoutExt = file.name.replace(/\.[^/.]+$/, '');
      formData.append('name', nameWithoutExt.length >= 3 ? nameWithoutExt : `report_${Date.now()}`);
      const result = await uploadFile(formData);
      if (result.success && result.data) {
        setReportFilePath((result.data as any).filePath || '');
        setReportOriginalName((result.data as any).originalName || file.name);
        toast.success('প্রতিবেদন সফলভাবে আপলোড হয়েছে!');
      } else {
        toast.error(result.message || 'ফাইল আপলোড ব্যর্থ হয়েছে!');
      }
    } catch {
      toast.error('ফাইল আপলোড করার সময় ত্রুটি হয়েছে!');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    setIsSubmitting(true);

    const filterPersons = (list: PersonalInfo[]) =>
      list.filter(p => p.name.trim() || p.parentName.trim() || p.address.trim() || p.mobile.trim());

    try {
      const payload = {
        moujaId,
        caseNo,
        inclusionDate,
        sabakSaKhotianNo,
        sabakSaDagNo,
        halKhotianNo,
        halDagNo,
        dagLandSize,
        category,
        lastRenewalYear,
        originalOwnerInfo: filterPersons(originalOwnerInfo),
        lesseeInfo: filterPersons(lesseeInfo),
        caseInfo,
        governmentPossessionDate,
        reportFilePath,
        reportOriginalName,
        comment,
      };

      let result;
      if (editingId) {
        result = await updateAbandoned({ id: editingId, ...payload });
      } else {
        result = await createAbandoned(payload);
      }

      if (result.success) {
        toast.success(result.message);
        router.refresh();
        resetForm();
      } else {
        toast.error(result.message);
      }
    } catch {
      toast.error('তথ্য সংরক্ষণের সময় একটি ত্রুটি ঘটেছে!');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Progress calculation
  const filledFields = [moujaId, caseNo, inclusionDate, sabakSaKhotianNo, sabakSaDagNo, halKhotianNo, halDagNo, dagLandSize];
  const filledCount = filledFields.filter(Boolean).length;
  const progress = Math.round((filledCount / filledFields.length) * 100);

  return (
    <div className="min-h-screen bg-gradient-to-br">
      <div className="mx-auto space-y-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Form */}
          <div className="lg:col-span-2 space-y-6">

            {/* Section 1: মৌলিক তথ্য */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-green-200 to-emerald-200 text-green-800 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  মৌলিক তথ্য
                </CardTitle>
                <CardDescription className="text-green-800">অর্পিত সম্পত্তির প্রাথমিক তথ্যাদি প্রদান করুন</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* Mouja */}
                <div ref={moujaRef} className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <MapPin className="h-4 w-4 text-green-500" />
                    মৌজা
                    <span className="text-red-500 ml-0.5">*</span>
                  </Label>
                  <div className={errors.moujaId ? 'rounded-md ring-2 ring-red-500' : ''}>
                    <MoujaSelect
                      mouzaData={mouzaData}
                      value={moujaId}
                      setValue={(val: string) => { setMoujaId(val); if (val) setErrors(prev => ({ ...prev, moujaId: false })); }}
                    />
                  </div>
                  {errors.moujaId && <p className="text-red-500 text-xs">মৌজা নির্বাচন করুন</p>}
                </div>

                {/* Case No */}
                <div ref={caseNoRef} className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Hash className="h-4 w-4 text-green-500" />
                    কেস নথি নং
                    <span className="text-red-500 ml-0.5">*</span>
                  </Label>
                  <Input
                    value={caseNo}
                    onChange={e => { setCaseNo(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, caseNo: false })); }}
                    placeholder="কেস নথি নং লিখুন..."
                    className={`h-12 border-slate-300 focus:border-green-500 focus:ring-green-500${errors.caseNo ? ' border-red-500 ring-1 ring-red-500' : ''}`}
                  />
                  {errors.caseNo && <p className="text-red-500 text-xs">কেস নথি নং প্রদান করুন</p>}
                </div>

                {/* Inclusion Date */}
                <div ref={inclusionDateRef} className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Calendar className="h-4 w-4 text-green-500" />
                    নথিতে তালিকাভুক্তির তারিখ
                    <span className="text-red-500 ml-0.5">*</span>
                  </Label>
                  <div className={errors.inclusionDate ? 'rounded-md ring-2 ring-red-500' : ''}>
                    <DatePickerField
                      value={inclusionDate}
                      onChange={val => { setInclusionDate(val); if (val) setErrors(prev => ({ ...prev, inclusionDate: false })); }}
                      placeholder="তারিখ নির্বাচন করুন"
                    />
                  </div>
                  {errors.inclusionDate && <p className="text-red-500 text-xs">তালিকাভুক্তির তারিখ প্রদান করুন</p>}
                </div>
              </CardContent>
            </Card>

            {/* Section 2: খতিয়ান ও দাগ তথ্য */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-blue-200 to-indigo-200 text-blue-800 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  খতিয়ান ও দাগ তথ্য
                </CardTitle>
                <CardDescription className="text-blue-800">সাবেক ও হাল খতিয়ান এবং দাগ নম্বর প্রদান করুন</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  {/* Sabak SA Khotian No */}
                  <div ref={sabakSaKhotianNoRef} className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Hash className="h-4 w-4 text-blue-500" />
                      সাবেক SA খতিয়ান নং
                      <span className="text-red-500 ml-0.5">*</span>
                    </Label>
                    <Input
                      value={sabakSaKhotianNo}
                      onChange={e => { setSabakSaKhotianNo(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, sabakSaKhotianNo: false })); }}
                      placeholder="সাবেক SA খতিয়ান নং..."
                      className={`h-12 border-slate-300 focus:border-blue-500 focus:ring-blue-500${errors.sabakSaKhotianNo ? ' border-red-500 ring-1 ring-red-500' : ''}`}
                    />
                    {errors.sabakSaKhotianNo && <p className="text-red-500 text-xs">সাবেক SA খতিয়ান নং প্রদান করুন</p>}
                  </div>

                  {/* Sabak SA Dag No */}
                  <div ref={sabakSaDagNoRef} className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Hash className="h-4 w-4 text-blue-500" />
                      সাবেক SA দাগ নং
                      <span className="text-red-500 ml-0.5">*</span>
                    </Label>
                    <Input
                      value={sabakSaDagNo}
                      onChange={e => { setSabakSaDagNo(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, sabakSaDagNo: false })); }}
                      placeholder="সাবেক SA দাগ নং..."
                      className={`h-12 border-slate-300 focus:border-blue-500 focus:ring-blue-500${errors.sabakSaDagNo ? ' border-red-500 ring-1 ring-red-500' : ''}`}
                    />
                    {errors.sabakSaDagNo && <p className="text-red-500 text-xs">সাবেক SA দাগ নং প্রদান করুন</p>}
                  </div>

                  {/* Hal Khotian No */}
                  <div ref={halKhotianNoRef} className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Hash className="h-4 w-4 text-indigo-500" />
                      হাল খতিয়ান নং
                      <span className="text-red-500 ml-0.5">*</span>
                    </Label>
                    <Input
                      value={halKhotianNo}
                      onChange={e => { setHalKhotianNo(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, halKhotianNo: false })); }}
                      placeholder="হাল খতিয়ান নং..."
                      className={`h-12 border-slate-300 focus:border-indigo-500 focus:ring-indigo-500${errors.halKhotianNo ? ' border-red-500 ring-1 ring-red-500' : ''}`}
                    />
                    {errors.halKhotianNo && <p className="text-red-500 text-xs">হাল খতিয়ান নং প্রদান করুন</p>}
                  </div>

                  {/* Hal Dag No */}
                  <div ref={halDagNoRef} className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Hash className="h-4 w-4 text-indigo-500" />
                      হাল দাগ নং
                      <span className="text-red-500 ml-0.5">*</span>
                    </Label>
                    <Input
                      value={halDagNo}
                      onChange={e => { setHalDagNo(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, halDagNo: false })); }}
                      placeholder="হাল দাগ নং..."
                      className={`h-12 border-slate-300 focus:border-indigo-500 focus:ring-indigo-500${errors.halDagNo ? ' border-red-500 ring-1 ring-red-500' : ''}`}
                    />
                    {errors.halDagNo && <p className="text-red-500 text-xs">হাল দাগ নং প্রদান করুন</p>}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Section 3: জমির বিবরণ */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-indigo-200 to-purple-200 text-purple-700 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Scale className="h-5 w-5" />
                  জমির বিবরণ
                </CardTitle>
                <CardDescription className="text-purple-800">জমি সংক্রান্ত বিস্তারিত তথ্য</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  {/* Dag Land Size */}
                  <div ref={dagLandSizeRef} className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Scale className="h-4 w-4 text-purple-500" />
                      জমির পরিমাণ (একর)
                      <span className="text-red-500 ml-0.5">*</span>
                    </Label>
                    <Input
                      value={dagLandSize}
                      onChange={e => { setDagLandSize(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, dagLandSize: false })); }}
                      placeholder="জমির পরিমাণ লিখুন..."
                      className={`h-12 border-slate-300 focus:border-purple-500 focus:ring-purple-500${errors.dagLandSize ? ' border-red-500 ring-1 ring-red-500' : ''}`}
                    />
                    {errors.dagLandSize && <p className="text-red-500 text-xs">জমির পরিমাণ প্রদান করুন</p>}
                  </div>

                  {/* Category */}
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Scale className="h-4 w-4 text-purple-500" />
                      শ্রেণী
                    </Label>
                    <Input
                      value={category}
                      onChange={e => setCategory(e.target.value)}
                      placeholder="শ্রেণী লিখুন..."
                      className="h-12 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                    />
                  </div>
                </div>

                {/* Last Renewal Year */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Calendar className="h-4 w-4 text-purple-500" />
                    সর্বশেষ লীজ প্রদান/নবায়নের সাল
                  </Label>
                  <Input
                    value={lastRenewalYear}
                    onChange={e => setLastRenewalYear(e.target.value)}
                    placeholder="বাংলা সন লিখুন..."
                    className="h-12 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Section 4: মূল মালিকের তথ্য */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-purple-200 to-pink-200 text-purple-700 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  মূল মালিকের তথ্য
                </CardTitle>
                <CardDescription className="text-purple-800">জমির মূল মালিকের বিস্তারিত তথ্য</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <PersonalInfoManager personalInfo={originalOwnerInfo} onChange={setOriginalOwnerInfo} />
              </CardContent>
            </Card>

            {/* Section 5: লীজ গ্রহীতার তথ্য */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-pink-200 to-rose-200 text-rose-700 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  লীজ গ্রহীতার তথ্য
                </CardTitle>
                <CardDescription className="text-rose-800">লীজ গ্রহীতার বিস্তারিত তথ্য</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <PersonalInfoManager personalInfo={lesseeInfo} onChange={setLesseeInfo} />
              </CardContent>
            </Card>

            {/* Section 6: অতিরিক্ত তথ্য */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-orange-100 to-red-100 text-orange-700 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  অতিরিক্ত তথ্য
                </CardTitle>
                <CardDescription className="text-orange-800">মামলা, দখল, প্রতিবেদন ও মন্তব্য সংক্রান্ত তথ্য</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* Case Info */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Scale className="h-4 w-4 text-orange-500" />
                    মামলা সংক্রান্ত তথ্য
                  </Label>
                  <Input
                    value={caseInfo}
                    onChange={e => setCaseInfo(e.target.value)}
                    placeholder="মামলা সংক্রান্ত তথ্য লিখুন..."
                    className="h-12 border-slate-300 focus:border-orange-500 focus:ring-orange-500"
                  />
                </div>

                {/* Government Possession Date */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Calendar className="h-4 w-4 text-orange-500" />
                    সরকার কর্তৃক দখলের তারিখ
                  </Label>
                  <DatePickerField
                    value={governmentPossessionDate}
                    onChange={setGovernmentPossessionDate}
                    placeholder="তারিখ নির্বাচন করুন"
                  />
                </div>

                {/* Report Upload */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Upload className="h-4 w-4 text-orange-500" />
                    সংশ্লিষ্ট প্রতিবেদন আপলোড
                  </Label>
                  <div className="flex flex-col gap-2">
                    <label
                      htmlFor="report-upload"
                      className={`flex items-center gap-3 h-12 px-4 rounded-md border border-dashed cursor-pointer transition-colors
                        ${isUploading ? 'border-slate-300 bg-slate-50' : 'border-orange-300 bg-orange-50 hover:bg-orange-100'}`}
                    >
                      {isUploading ? (
                        <Loader2 className="h-4 w-4 animate-spin text-orange-500" />
                      ) : (
                        <Upload className="h-4 w-4 text-orange-500" />
                      )}
                      <span className="text-sm text-slate-600">
                        {isUploading ? 'আপলোড হচ্ছে...' : reportOriginalName ? reportOriginalName : 'ফাইল নির্বাচন করুন (PDF, Word, Image)'}
                      </span>
                      <input
                        id="report-upload"
                        type="file"
                        className="hidden"
                        accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.gif,.xls,.xlsx,.csv"
                        onChange={handleFileUpload}
                        disabled={isUploading}
                      />
                    </label>
                    {reportOriginalName && (
                      <div className="flex items-center justify-between text-xs text-green-700 bg-green-50 rounded px-3 py-2">
                        <span>✓ {reportOriginalName}</span>
                        <button
                          type="button"
                          onClick={() => { setReportFilePath(''); setReportOriginalName(''); }}
                          className="text-red-500 hover:text-red-700 ml-2"
                        >
                          সরান
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Comment */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <MessageSquare className="h-4 w-4 text-orange-500" />
                    মন্তব্য
                  </Label>
                  <Input
                    value={comment}
                    onChange={e => setComment(e.target.value)}
                    placeholder="মন্তব্য লিখুন..."
                    className="h-12 border-slate-300 focus:border-orange-500 focus:ring-orange-500"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6 flex flex-col sticky top-4 justify-start">
            {/* Progress Card */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-gradient-to-br from-green-600 to-emerald-700 text-white">
              <CardContent className="p-6">
                <div className="text-center space-y-4">
                  <CheckCircle2 className="h-12 w-12 mx-auto text-white/80" />
                  <h3 className="text-lg font-semibold">ফর্ম অগ্রগতি</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>প্রয়োজনীয় তথ্য</span>
                      <span>{filledCount}/{filledFields.length}</span>
                    </div>
                    <div className="w-full bg-white/30 rounded-full h-2">
                      <div
                        className="bg-white rounded-full h-2 transition-all duration-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <p className="text-xs text-white/70">{progress}% সম্পন্ন</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6 space-y-4">
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting || isUploading}
                  className={`w-full h-12 text-white font-semibold shadow-lg transition-all duration-200
                    ${editingId
                      ? 'bg-yellow-600 hover:bg-yellow-700'
                      : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-700 hover:to-teal-700'
                    }`}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      সংরক্ষণ হচ্ছে...
                    </>
                  ) : editingId ? (
                    <>
                      <Pencil className="h-4 w-4 mr-2" />
                      আপডেট করুন
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      সংরক্ষণ করুন
                    </>
                  )}
                </Button>

                <Button
                  onClick={resetForm}
                  variant="outline"
                  className="w-full h-12 border-slate-300 text-slate-700 hover:bg-slate-50 transition-all duration-200"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  ফর্ম রিসেট করুন
                </Button>
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-slate-800">
                  <Sparkles className="h-5 w-5 text-yellow-500" />
                  দ্রুত টিপস
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
                  <span className="text-xs font-medium text-red-700">* চিহ্নিত ঘরগুলো অবশ্যই পূরণ করতে হবে।</span>
                </div>
                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <span className="text-xs text-blue-700">সাবেক ও হাল খতিয়ান/দাগ নম্বর সঠিকভাবে প্রদান করুন।</span>
                </div>
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <span className="text-xs text-green-700">প্রতিবেদন আপলোডের পর সংরক্ষণ করুন।</span>
                </div>
                <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
                  <span className="text-xs text-purple-700">একাধিক মালিক বা লীজ গ্রহীতা থাকলে + বোতাম দিয়ে যুক্ত করুন।</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateAbandonedProperty;
