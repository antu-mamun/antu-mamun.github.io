'use client';

import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, Calendar, Filter, X, RefreshCw } from 'lucide-react';

interface FileFilterProps {
    onFilterChange: (filters: {
        search: string;
        startDate?: Date;
        endDate?: Date;
    }) => void;
    isLoading?: boolean;
}

export function FileFilter({ onFilterChange, isLoading }: FileFilterProps) {
    const [search, setSearch] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    // Simple change handlers without debouncing
    const handleSearchChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        setSearch(event.target.value);
    }, []);

    const handleStartDateChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        setStartDate(event.target.value);
    }, []);

    const handleEndDateChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        setEndDate(event.target.value);
    }, []);

    // Filter button handler
    const handleApplyFilters = useCallback(() => {
        try {
            onFilterChange({
                search: search.trim(),
                startDate: startDate ? new Date(startDate) : undefined,
                endDate: endDate ? new Date(endDate + 'T23:59:59') : undefined,
            });
        } catch (error) {
            console.error('Error applying filters:', error);
        }
    }, [search, startDate, endDate, onFilterChange]);

    // Handle Enter key press in search input
    const handleSearchKeyPress = useCallback((event: React.KeyboardEvent<HTMLInputElement>) => {
        if (event.key === 'Enter') {
            handleApplyFilters();
        }
    }, [handleApplyFilters]);

    const handleClearSearch = useCallback(() => {
        setSearch('');
    }, []);

    const handleClearStartDate = useCallback(() => {
        setStartDate('');
    }, []);

    const handleClearEndDate = useCallback(() => {
        setEndDate('');
    }, []);

    const handleClearFilters = useCallback(() => {
        setSearch('');
        setStartDate('');
        setEndDate('');
        onFilterChange({
            search: '',
            startDate: undefined,
            endDate: undefined,
        });
    }, [onFilterChange]);

    const hasActiveFilters = search.trim() || startDate || endDate;
    const hasChangesToApply = search.trim() || startDate || endDate;

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Filter className="h-5 w-5" />
                    ফাইল খুঁজুন ও ফিল্টার করুন
                    {hasActiveFilters && (
                        <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded-full">
                            {[search.trim(), startDate, endDate].filter(Boolean).length} ফিল্টার সক্রিয়
                        </span>
                    )}
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {/* Search by name */}
                        <div className="space-y-2">
                            <Label htmlFor="search">নাম অনুসারে খুঁজুন</Label>
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input
                                    id="search"
                                    type="text"
                                    value={search}
                                    onChange={handleSearchChange}
                                    onKeyPress={handleSearchKeyPress}
                                    placeholder="ফাইলের নাম লিখুন..."
                                    className="pl-10 pr-10"
                                    disabled={isLoading}
                                />
                                {search && (
                                    <button
                                        type="button"
                                        onClick={handleClearSearch}
                                        className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground hover:text-foreground"
                                        disabled={isLoading}
                                    >
                                        <X className="h-4 w-4" />
                                    </button>
                                )}
                            </div>
                        </div>

                        {/* Start date */}
                        <div className="space-y-2">
                            <Label htmlFor="start-date">শুরুর তারিখ</Label>
                            <div className="relative">
                                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input
                                    id="start-date"
                                    type="date"
                                    value={startDate}
                                    onChange={handleStartDateChange}
                                    className="pl-10 pr-10"
                                    disabled={isLoading}
                                />
                                {startDate && (
                                    <button
                                        type="button"
                                        onClick={handleClearStartDate}
                                        className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground hover:text-foreground"
                                        disabled={isLoading}
                                    >
                                        <X className="h-4 w-4" />
                                    </button>
                                )}
                            </div>
                        </div>

                        {/* End date */}
                        <div className="space-y-2">
                            <Label htmlFor="end-date">শেষের তারিখ</Label>
                            <div className="relative">
                                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input
                                    id="end-date"
                                    type="date"
                                    value={endDate}
                                    onChange={handleEndDateChange}
                                    className="pl-10 pr-10"
                                    disabled={isLoading}
                                />
                                {endDate && (
                                    <button
                                        type="button"
                                        onClick={handleClearEndDate}
                                        className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground hover:text-foreground"
                                        disabled={isLoading}
                                    >
                                        <X className="h-4 w-4" />
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex flex-wrap gap-3 justify-between items-center">
                        <div className="flex gap-2">
                            <Button
                                type="button"
                                onClick={handleApplyFilters}
                                disabled={isLoading || !hasChangesToApply}
                                className="flex items-center gap-2"
                            >
                                <Search className="h-4 w-4" />
                                {isLoading ? 'খোঁজ করা হচ্ছে...' : 'ফিল্টার প্রয়োগ করুন'}
                            </Button>

                            {hasActiveFilters && (
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={handleClearFilters}
                                    disabled={isLoading}
                                    className="flex items-center gap-2"
                                >
                                    <X className="h-4 w-4" />
                                    সব ফিল্টার পরিষ্কার করুন
                                </Button>
                            )}
                        </div>

                        {hasChangesToApply && (
                            <div className="text-sm text-muted-foreground">
                                ফিল্টার করতে "ফিল্টার প্রয়োগ করুন" বাটনে ক্লিক করুন বা Enter চাপুন
                            </div>
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}
