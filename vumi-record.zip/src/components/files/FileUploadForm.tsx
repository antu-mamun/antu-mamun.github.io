'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, File } from 'lucide-react';
import { uploadFile } from '@/actions/files';
import { toast } from 'sonner';

interface FileUploadFormProps {
    onUploadSuccess?: () => void;
}

export function FileUploadForm({ onUploadSuccess }: FileUploadFormProps) {
    const [isUploading, setIsUploading] = useState(false);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState('');

    const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            // Client-side validation
            const maxSize = 10 * 1024 * 1024; // 10MB
            if (file.size > maxSize) {
                toast.error('ফাইলের আকার ১০ এমবি এর বেশি হতে পারে না।');
                event.target.value = '';
                return;
            }

            if (file.size === 0) {
                toast.error('খালি ফাইল আপলোড করা যাবে না।');
                event.target.value = '';
                return;
            }

            // Check allowed file types
            const allowedTypes = [
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'text/plain',
                'image/jpeg',
                'image/jpg',
                'image/png',
                'image/gif',
                'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'text/csv'
            ];

            if (!allowedTypes.includes(file.type)) {
                toast.error('অনুমতিপ্রাপ্ত ফাইল ধরন: PDF, Word, Text, Image, Excel, CSV।');
                event.target.value = '';
                return;
            }

            setSelectedFile(file);
            // Set default name to original filename without extension
            const nameWithoutExt = file.name.replace(/\.[^/.]+$/, '');
            setFileName(nameWithoutExt);
        }
    };

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        if (!selectedFile || !fileName.trim()) {
            toast.error('দয়া করে একটি ফাইল নির্বাচন করুন এবং নাম দিন');
            return;
        }

        // Validate file name length
        if (fileName.trim().length < 3) {
            toast.error('ফাইলের নাম কমপক্ষে ৩ অক্ষরের হতে হবে।');
            return;
        }

        if (fileName.trim().length > 100) {
            toast.error('ফাইলের নাম ১০০ অক্ষরের বেশি হতে পারে না।');
            return;
        }

        setIsUploading(true);

        try {
            const formData = new FormData();
            formData.append('file', selectedFile);
            formData.append('name', fileName.trim());

            const result = await uploadFile(formData);

            if (result.success) {
                toast.success(result.message);
                // Reset form
                setSelectedFile(null);
                setFileName('');
                const fileInput = document.getElementById('file-input') as HTMLInputElement;
                if (fileInput) fileInput.value = '';

                onUploadSuccess?.();
            } else {
                toast.error(result.message);
            }
        } catch (error) {
            console.error('Upload error:', error);
            toast.error('ফাইল আপলোড করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।');
        } finally {
            setIsUploading(false);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    ফাইল আপলোড করুন
                </CardTitle>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="file-input">ফাইল নির্বাচন করুন</Label>
                        <Input
                            id="file-input"
                            type="file"
                            onChange={handleFileSelect}
                            accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.gif,.xlsx,.xls,.csv"
                            className="cursor-pointer"
                        />
                        <p className="text-xs text-muted-foreground">
                            সর্বোচ্চ ফাইলের আকার: ১০ এমবি। অনুমতিপ্রাপ্ত ধরন: PDF, Word, Text, Image, Excel, CSV
                        </p>
                        {selectedFile && (
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <File className="h-4 w-4" />
                                <span>{selectedFile.name}</span>
                                <span>({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)</span>
                            </div>
                        )}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="file-name">ফাইলের নাম (৩-১০০ অক্ষর)</Label>
                        <Input
                            id="file-name"
                            type="text"
                            value={fileName}
                            onChange={(e) => setFileName(e.target.value)}
                            placeholder="ফাইলের জন্য একটি নাম লিখুন"
                            minLength={3}
                            maxLength={100}
                            required
                        />
                    </div>

                    <Button
                        type="submit"
                        disabled={!selectedFile || !fileName.trim() || isUploading}
                        className="w-full"
                    >
                        {isUploading ? 'আপলোড হচ্ছে...' : 'ফাইল আপলোড করুন'}
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
}
