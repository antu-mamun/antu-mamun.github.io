'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from '@/components/ui/dialog';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import {
    File,
    Edit,
    Trash2,
    Download,
    Eye,
    Calendar,
    HardDrive
} from 'lucide-react';
import { updateFileName, deleteFile } from '@/actions/files';
import { toast } from 'sonner';
import { FileUploadType } from '@/actions/files';

interface FileListProps {
    files: FileUploadType[];
    onFileUpdate?: () => void;
}

export function FileList({ files, onFileUpdate }: FileListProps) {
    const [editingFile, setEditingFile] = useState<FileUploadType | null>(null);
    const [newFileName, setNewFileName] = useState('');
    const [isUpdating, setIsUpdating] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    const formatFileSize = (bytes: number) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const formatDate = (date: Date | string) => {
        const dateObj = typeof date === 'string' ? new Date(date) : date;
        return dateObj.toLocaleDateString('bn-BD', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    };

    const handleEditStart = (file: FileUploadType) => {
        setEditingFile(file);
        setNewFileName(file.name);
    };

    const handleEditCancel = () => {
        setEditingFile(null);
        setNewFileName('');
    };

    const handleEditSave = async () => {
        if (!editingFile || !newFileName.trim()) {
            toast.error('Please provide a valid name');
            return;
        }

        setIsUpdating(true);
        try {
            const result = await updateFileName({
                id: editingFile.id,
                name: newFileName.trim(),
            });

            if (result.success) {
                toast.success(result.message);
                setEditingFile(null);
                setNewFileName('');
                onFileUpdate?.();
            } else {
                toast.error(result.message);
            }
        } catch (error) {
            console.error('Update error:', error);
            toast.error('Failed to update file name');
        } finally {
            setIsUpdating(false);
        }
    };

    const handleDelete = async (id: string) => {
        setIsDeleting(true);
        try {
            const result = await deleteFile(id);

            if (result.success) {
                toast.success(result.message);
                onFileUpdate?.();
            } else {
                toast.error(result.message);
            }
        } catch (error) {
            console.error('Delete error:', error);
            toast.error('Failed to delete file');
        } finally {
            setIsDeleting(false);
        }
    };

    const handleDownload = async (file: FileUploadType) => {
        try {
            // Use secure API endpoint for downloading
            const response = await fetch(`/api/files/${file.id}?action=download`);

            if (!response.ok) {
                if (response.status === 401) {
                    toast.error('আপনার লগইন সেশন শেষ হয়ে গেছে। পুনরায় লগইন করুন।');
                    return;
                }
                throw new Error('ফাইল ডাউনলোড করতে ব্যর্থ');
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = file.originalName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);

            toast.success('ফাইল সফলভাবে ডাউনলোড হয়েছে');
        } catch (error) {
            console.error('Download error:', error);
            toast.error('ফাইল ডাউনলোড করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।');
        }
    };

    const handlePreview = async (file: FileUploadType) => {
        try {
            // Use secure API endpoint for preview
            const url = `/api/files/${file.id}?action=preview`;

            // Check if the endpoint is accessible
            const response = await fetch(url, { method: 'HEAD' });

            if (!response.ok) {
                if (response.status === 401) {
                    toast.error('আপনার লগইন সেশন শেষ হয়ে গেছে। পুনরায় লগইন করুন।');
                    return;
                }
                throw new Error('ফাইল প্রিভিউ করতে ব্যর্থ');
            }

            // Open in new tab if accessible
            window.open(url, '_blank');
        } catch (error) {
            console.error('Preview error:', error);
            toast.error('ফাইল প্রিভিউ করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।');
        }
    };

    if (files.length === 0) {
        return (
            <div className="text-center py-8">
                <File className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">কোনো ফাইল পাওয়া যায়নি</p>
            </div>
        );
    }

    return (
        <div className="border rounded-lg">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>নাম</TableHead>
                        <TableHead>মূল নাম</TableHead>
                        <TableHead>আকার</TableHead>
                        <TableHead>ধরন</TableHead>
                        <TableHead>আপলোড তারিখ</TableHead>
                        <TableHead>অ্যাকশন</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {files.map((file) => (
                        <TableRow key={file.id}>
                            <TableCell className="font-medium">{file.name}</TableCell>
                            <TableCell className="text-muted-foreground">
                                {file.originalName}
                            </TableCell>
                            <TableCell>
                                <div className="flex items-center gap-1">
                                    <HardDrive className="h-4 w-4 text-muted-foreground" />
                                    {formatFileSize(file.fileSize)}
                                </div>
                            </TableCell>
                            <TableCell>
                                <Badge variant="outline">
                                    {file.mimeType.split('/')[1]?.toUpperCase() || 'FILE'}
                                </Badge>
                            </TableCell>
                            <TableCell>
                                <div className="flex items-center gap-1">
                                    <Calendar className="h-4 w-4 text-muted-foreground" />
                                    {formatDate(file.createdAt)}
                                </div>
                            </TableCell>
                            <TableCell>
                                <div className="flex items-center gap-2">
                                    {/* Preview Button */}
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => handlePreview(file)}
                                        className="h-8 w-8 p-0"
                                    >
                                        <Eye className="h-4 w-4" />
                                    </Button>

                                    {/* Download Button */}
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => handleDownload(file)}
                                        className="h-8 w-8 p-0"
                                    >
                                        <Download className="h-4 w-4" />
                                    </Button>

                                    {/* Edit Name Dialog */}
                                    <Dialog>
                                        <DialogTrigger asChild>
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => handleEditStart(file)}
                                                className="h-8 w-8 p-0"
                                            >
                                                <Edit className="h-4 w-4" />
                                            </Button>
                                        </DialogTrigger>
                                        <DialogContent>
                                            <DialogHeader>
                                                <DialogTitle>ফাইলের নাম সম্পাদনা করুন</DialogTitle>
                                            </DialogHeader>
                                            <div className="space-y-4">
                                                <div className="space-y-2">
                                                    <Label htmlFor="edit-name">নতুন নাম</Label>
                                                    <Input
                                                        id="edit-name"
                                                        value={newFileName}
                                                        onChange={(e) => setNewFileName(e.target.value)}
                                                        placeholder="ফাইলের নতুন নাম লিখুন"
                                                    />
                                                </div>
                                                <div className="flex gap-2">
                                                    <Button
                                                        onClick={handleEditSave}
                                                        disabled={isUpdating || !newFileName.trim()}
                                                        className="flex-1"
                                                    >
                                                        {isUpdating ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন'}
                                                    </Button>
                                                    <Button
                                                        variant="outline"
                                                        onClick={handleEditCancel}
                                                        disabled={isUpdating}
                                                    >
                                                        বাতিল
                                                    </Button>
                                                </div>
                                            </div>
                                        </DialogContent>
                                    </Dialog>

                                    {/* Delete Button */}
                                    <AlertDialog>
                                        <AlertDialogTrigger asChild>
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </AlertDialogTrigger>
                                        <AlertDialogContent>
                                            <AlertDialogHeader>
                                                <AlertDialogTitle>ফাইল মুছে ফেলুন</AlertDialogTitle>
                                                <AlertDialogDescription>
                                                    আপনি কি নিশ্চিত যে আপনি &quot;{file.name}&quot; ফাইলটি মুছে ফেলতে চান?
                                                    এই কাজটি আর ফিরিয়ে আনা যাবে না।
                                                </AlertDialogDescription>
                                            </AlertDialogHeader>
                                            <AlertDialogFooter>
                                                <AlertDialogCancel disabled={isDeleting}>
                                                    বাতিল
                                                </AlertDialogCancel>
                                                <AlertDialogAction
                                                    onClick={() => handleDelete(file.id)}
                                                    disabled={isDeleting}
                                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                                >
                                                    {isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'মুছে ফেলুন'}
                                                </AlertDialogAction>
                                            </AlertDialogFooter>
                                        </AlertDialogContent>
                                    </AlertDialog>
                                </div>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
}
