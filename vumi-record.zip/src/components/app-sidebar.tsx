'use client';

import * as React from 'react';
import {
  LayoutDashboard,
  MapPin,
  Sparkles,
  Building2,
  Users,
  Upload,
  Map,
  BookOpen,
} from 'lucide-react';
import { NavMain } from '@/components/nav-main';
import { NavUser } from '@/components/nav-user';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarRail,
} from '@/components/ui/sidebar';
import { User } from '@/generated/prisma';

type AppSidebarProps = React.ComponentProps<typeof Sidebar> & {
  user: User | null;
  role: string; // 'ADMIN' | 'EDITOR' | 'USER'
};

export function AppSidebar({ user, role, ...props }: AppSidebarProps) {
  const navAll = [
    {
      title: 'ড্যাশবোর্ড',
      url: '/dashboard',
      icon: LayoutDashboard,
    },
    {
      title: 'মৌজা তৈরি করুন',
      url: '/create-mouja',
      icon: MapPin,
    },
    {
      title: 'রেজিস্টার ৮ এর তথ্য এন্ট্রি',
      url: '/create-nothi',
      icon: Sparkles,
    },
    {
      title: 'অর্পিত সম্পত্তির তথ্য এন্ট্রি',
      url: '/create-abandoned-property',
      icon: Building2,
    },
    {
      title: 'মৌজা ম্যাপ এন্ট্রি',
      url: '/mouja-map',
      icon: Map,
    },
    {
      title: 'দাগ সূচি এন্ট্রি',
      url: '/dag-suchi',
      icon: BookOpen,
    },
    {
      title: 'ফাইল আপলোড ও ব্যবস্থাপনা',
      url: '/file-upload',
      icon: Upload,
    },
    {
      title: 'ব্যবহারকারী পরিচালন',
      url: '/user-management',
      icon: Users,
    },
  ];

  let navFiltered: typeof navAll = [];

  if (role === 'ADMIN') {
    navFiltered = navAll;
  } else if (role === 'EDITOR') {
    navFiltered = navAll.filter(item => item.url !== '/user-management');
  } else if (role === 'USER') {
    navFiltered = navAll.filter(item =>
      item.url === '/dashboard' || item.url === '/file-upload'
    );
  }

  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarContent>
        <NavMain items={navFiltered} />
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={user} />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
