'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Eye, FileText, Loader2, Pencil, Search, Trash2, X } from 'lucide-react';
import { deleteDagSuchi } from '@/actions/dagSuchi';
import { toast } from 'sonner';
import { useRouter } from 'next/navigation';

type DagSuchiItem = {
  id: string;
  moujaId: string;
  fileName: string;
  originalName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
  createdAt: Date;
  mouja: { name: string; jlNo: string };
};

type PreviewState = { filePath: string; originalName: string; mimeType: string } | null;

const FilePreviewModal = ({ preview, onClose }: { preview: PreviewState; onClose: () => void }) => {
  const [blobUrl, setBlobUrl] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);
  const prevBlobRef = useRef<string | null>(null);

  useEffect(() => {
    if (!preview) {
      if (prevBlobRef.current) {
        URL.revokeObjectURL(prevBlobRef.current);
        prevBlobRef.current = null;
      }
      setBlobUrl(null);
      return;
    }

    setLoading(true);
    setBlobUrl(null);

    fetch(`/api/files/preview?path=${encodeURIComponent(preview.filePath)}`)
      .then(res => {
        if (res.status === 401) {
          toast.error('আপনার লগইন সেশন শেষ হয়ে গেছে। পুনরায় লগইন করুন।');
          onClose();
          return null;
        }
        if (!res.ok) {
          toast.error('ফাইল লোড করতে ব্যর্থ হয়েছে।');
          onClose();
          return null;
        }
        return res.blob();
      })
      .then(blob => {
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        prevBlobRef.current = url;
        setBlobUrl(url);
      })
      .catch(() => {
        toast.error('ফাইল লোড করতে ব্যর্থ হয়েছে।');
        onClose();
      })
      .finally(() => setLoading(false));

    return () => {
      if (prevBlobRef.current) {
        URL.revokeObjectURL(prevBlobRef.current);
        prevBlobRef.current = null;
      }
    };
  }, [preview]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!preview) return null;

  const isImage = preview.mimeType.startsWith('image/');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="relative bg-white rounded-xl shadow-2xl flex flex-col w-full max-w-4xl max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Modal header */}
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <div className="flex items-center gap-2 text-sm font-medium text-gray-700 truncate">
            <FileText className="w-4 h-4 text-blue-600 shrink-0" />
            <span className="truncate max-w-[420px]">{preview.originalName}</span>
          </div>
          <Button size="icon" variant="ghost" onClick={onClose} className="shrink-0">
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Preview body */}
        <div className="flex-1 overflow-auto min-h-0 rounded-b-xl">
          {loading && (
            <div className="flex items-center justify-center min-h-[60vh] gap-3 text-gray-500">
              <Loader2 className="w-6 h-6 animate-spin" />
              <span>লোড হচ্ছে...</span>
            </div>
          )}
          {!loading && blobUrl && (
            isImage ? (
              <div className="flex items-center justify-center p-4 min-h-[60vh]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={blobUrl}
                  alt={preview.originalName}
                  className="max-w-full max-h-[75vh] object-contain rounded"
                />
              </div>
            ) : (
              <iframe
                src={blobUrl}
                className="w-full h-[75vh] rounded-b-xl border-0"
                title={preview.originalName}
              />
            )
          )}
        </div>
      </div>
    </div>
  );
};

const DagSuchiList = ({
  suchiList,
  onEdit,
}: {
  suchiList: DagSuchiItem[];
  onEdit?: (item: DagSuchiItem) => void;
}) => {
  const [search, setSearch] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [preview, setPreview] = useState<PreviewState>(null);
  const router = useRouter();

  const filtered = suchiList.filter(
    item =>
      item.mouja.name.toLowerCase().includes(search.toLowerCase()) ||
      item.mouja.jlNo.includes(search)
  );

  const handleDelete = async (id: string) => {
    if (!confirm('এই দাগ সূচি মুছে ফেলতে চান?')) return;
    setDeletingId(id);
    try {
      const res = await deleteDagSuchi(id);
      if (res.success) {
        toast.success(res.message);
        router.refresh();
      } else {
        toast.error(res.message);
      }
    } catch {
      toast.error('মুছতে ত্রুটি হয়েছে!');
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <>
      <FilePreviewModal preview={preview} onClose={() => setPreview(null)} />

      <div className="space-y-4">
        {/* Search */}
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="মৌজার নাম বা জে.এল. নং দিয়ে খুঁজুন..."
            className="pl-9"
          />
        </div>

        <div className="w-full overflow-x-auto rounded-md border border-blue-100">
          <Table>
            <TableHeader className="bg-gradient-to-r from-blue-50 to-indigo-100/50">
              <TableRow>
                <TableHead className="border border-blue-800 text-center whitespace-nowrap">ক্রমিক নং</TableHead>
                <TableHead className="border border-blue-800 text-center whitespace-nowrap">মৌজা</TableHead>
                <TableHead className="border border-blue-800 text-center whitespace-nowrap">জে.এল. নং</TableHead>
                <TableHead className="border border-blue-800 text-center whitespace-nowrap">দাগ সূচি ফাইল</TableHead>
                {onEdit && (
                  <TableHead className="border border-blue-800 text-center whitespace-nowrap">অ্যাকশন</TableHead>
                )}
              </TableRow>
            </TableHeader>
            <TableBody className="bg-white">
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={onEdit ? 5 : 4} className="text-center text-gray-400 py-10">
                    {search ? 'কোনো ফলাফল পাওয়া যায়নি।' : 'কোনো দাগ সূচি নেই।'}
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((item, index) => (
                  <TableRow key={item.id}>
                    <TableCell className="border border-blue-800 text-center">{index + 1}</TableCell>
                    <TableCell className="border border-blue-800 text-center">{item.mouja.name}</TableCell>
                    <TableCell className="border border-blue-800 text-center">{item.mouja.jlNo}</TableCell>
                    <TableCell className="border border-blue-800 text-center">
                      {item.filePath ? (
                        <Button
                          size="sm"
                          variant="outline"
                          className="inline-flex items-center gap-1.5 text-blue-700 border-blue-600 hover:bg-blue-50 text-xs"
                          onClick={() =>
                            setPreview({
                              filePath: item.filePath,
                              originalName: item.originalName || 'ফাইল',
                              mimeType: item.mimeType,
                            })
                          }
                        >
                          <Eye className="w-3.5 h-3.5" />
                          দেখুন
                        </Button>
                      ) : (
                        <span className="text-gray-400 text-sm">নেই</span>
                      )}
                    </TableCell>
                    {onEdit && (
                      <TableCell className="border border-blue-800 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="icon"
                            variant="outline"
                            className="text-green-700 border-green-700 hover:bg-green-50"
                            onClick={() => onEdit(item)}
                            title="এডিট করুন"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="outline"
                            className="text-red-600 border-red-600 hover:bg-red-50"
                            onClick={() => handleDelete(item.id)}
                            disabled={deletingId === item.id}
                            title="মুছুন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <p className="text-xs text-gray-400 text-right">মোট: {filtered.length} টি রেকর্ড</p>
      </div>
    </>
  );
};

export default DagSuchiList;
