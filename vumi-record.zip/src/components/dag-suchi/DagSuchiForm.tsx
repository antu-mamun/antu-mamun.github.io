'use client';

import React, { useEffect, useRef, useState } from 'react';
import { MoujaSelect } from '../mouja/MoujaSelect';
import { Button } from '../ui/button';
import { Mouja } from '@/generated/prisma';
import { createDagSuchi, updateDagSuchi } from '@/actions/dagSuchi';
import { toast } from 'sonner';
import { FileText, Pencil, RotateCcw, Save, Upload } from 'lucide-react';

type EditData = {
  id: string;
  moujaId: string;
  filePath: string;
  originalName: string;
};

const DagSuchiForm = ({
  mouzaData,
  editData,
  onFinishEdit,
  onSuccess,
}: {
  mouzaData: Mouja[];
  editData?: EditData | null;
  onFinishEdit?: () => void;
  onSuccess?: () => void;
}) => {
  const [moujaId, setMouja] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{ moujaId?: boolean }>({});
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const moujaRef = useRef<HTMLDivElement>(null);

  const isEditing = !!editData?.id;

  useEffect(() => {
    if (editData) {
      setMouja(editData.moujaId || '');
      setSelectedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } else {
      resetForm();
    }
  }, [editData]);

  const resetForm = () => {
    setMouja('');
    setSelectedFile(null);
    setErrors({});
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const validateForm = () => {
    const newErrors: { moujaId?: boolean } = {};
    if (!moujaId) newErrors.moujaId = true;

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      if (newErrors.moujaId) moujaRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      toast.error('অনুগ্রহ করে প্রয়োজনীয় তথ্য পূরণ করুন।');
      return false;
    }
    return true;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 20 * 1024 * 1024) {
      toast.error('ফাইলের আকার ২০ এমবি এর বেশি হতে পারে না।');
      e.target.value = '';
      return;
    }
    const allowed = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    if (!allowed.includes(file.type)) {
      toast.error('অনুমতিপ্রাপ্ত ফাইল ধরন: PDF, JPG, PNG, GIF।');
      e.target.value = '';
      return;
    }
    setSelectedFile(file);
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append('moujaId', moujaId);
      if (selectedFile) formData.append('dag_suchi_file_upload', selectedFile);

      let result;
      if (isEditing) {
        formData.append('id', editData.id);
        formData.append('existingFilePath', editData.filePath || '');
        result = await updateDagSuchi(formData);
      } else {
        result = await createDagSuchi(formData);
      }

      if (result.success) {
        toast.success(result.message);
        if (isEditing) {
          onFinishEdit?.();
        } else {
          resetForm();
          onSuccess?.();
        }
      } else {
        toast.error(result.message || 'সংরক্ষণ ব্যর্থ হয়েছে!');
      }
    } catch (err) {
      console.error(err);
      toast.error('একটি ত্রুটি ঘটেছে। আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form
      onSubmit={e => { e.preventDefault(); handleSubmit(); }}
      className="space-y-6"
    >
      {/* মৌজা */}
      <div ref={moujaRef} className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="flex items-center">
          <label className="mr-2 whitespace-nowrap font-medium">
            মৌজা <span className="text-red-500">*</span>
          </label>
        </div>
        <div className="col-span-2">
          <MoujaSelect
            mouzaData={mouzaData}
            value={moujaId}
            setValue={(val: string) => {
              setMouja(val);
              if (val) setErrors(prev => ({ ...prev, moujaId: false }));
            }}
          />
          {errors.moujaId && (
            <p className="text-red-500 text-xs mt-1">মৌজা নির্বাচন করুন।</p>
          )}
        </div>
      </div>

      {/* দাগ সূচি ফাইল */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="flex items-center">
          <label className="mr-2 whitespace-nowrap font-medium">দাগ সূচি ফাইল</label>
        </div>
        <div className="col-span-2 space-y-2">
          {isEditing && editData?.originalName && !selectedFile && (
            <div className="flex items-center gap-2 text-sm text-blue-700 bg-blue-50 px-3 py-2 rounded-md">
              <FileText className="w-4 h-4" />
              <span>বর্তমান ফাইল: {editData.originalName}</span>
              <span className="text-xs text-gray-500">(নতুন ফাইল নির্বাচন করলে প্রতিস্থাপিত হবে)</span>
            </div>
          )}
          <div className="flex items-center gap-3">
            <label
              htmlFor="dag-suchi-file"
              className="cursor-pointer flex items-center gap-2 px-4 py-2 border border-dashed border-gray-300 rounded-md text-sm text-gray-600 hover:border-blue-500 hover:text-blue-600 transition-colors"
            >
              <Upload className="w-4 h-4" />
              {selectedFile ? selectedFile.name : 'ফাইল নির্বাচন করুন'}
            </label>
            <input
              id="dag-suchi-file"
              ref={fileInputRef}
              type="file"
              accept=".pdf,.jpg,.jpeg,.png,.gif"
              onChange={handleFileSelect}
              className="hidden"
            />
            {selectedFile && (
              <span className="text-xs text-gray-500">
                ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
              </span>
            )}
          </div>
          <p className="text-xs text-gray-400">সর্বোচ্চ ২০ এমবি। অনুমতিপ্রাপ্ত: PDF, JPG, PNG, GIF</p>
        </div>
      </div>

      {/* Buttons */}
      <div className="flex gap-4 flex-wrap justify-end">
        <Button
          type="submit"
          disabled={isSubmitting}
          className={`text-white font-semibold shadow-lg transition-all duration-200 ${
            isEditing
              ? 'bg-yellow-600 hover:bg-yellow-700'
              : 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-700 hover:to-indigo-700'
          }`}
        >
          {isEditing ? (
            <><Pencil className="w-4 h-4" /> আপডেট করুন</>
          ) : (
            <><Save className="w-4 h-4" /> সংরক্ষণ করুন</>
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          className="border-amber-500 text-amber-500 hover:text-amber-700 hover:bg-amber-50 flex items-center gap-2"
          onClick={() => {
            if (isEditing) onFinishEdit?.();
            else resetForm();
          }}
        >
          <RotateCcw className="w-4 h-4" />
          {isEditing ? 'বাতিল' : 'রিসেট করুন'}
        </Button>
      </div>
    </form>
  );
};

export default DagSuchiForm;
