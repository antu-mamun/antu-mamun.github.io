'use client';

import React, { useState, useEffect, useRef } from 'react';
import { MoujaSelect } from '../mouja/MoujaSelect';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Badge } from "../ui/badge";
import { Label } from "../ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Mouja } from '@/generated/prisma';
import { createNothi, updateNothi } from '@/actions/nothi';
import { useRouter } from 'next/navigation';
import { InputTags } from './tag-input';
import { toast } from 'sonner';
import {
  FileText,
  MapPin,
  Hash,
  Scale,
  Calendar,
  User,
  MessageSquare,
  Save,
  RotateCcw,
  Sparkles,
  CheckCircle2,
} from "lucide-react";

import PersonalInfoManager, { type PersonalInfo } from './PersonalInfoManager';
import { DatePickerField } from '../common/DatePickerField';

type EditData = {
  id: string;
  moujaId: string;
  partNo: string;
  caseNo: string;
  khotianNo: string[];
  lineNo: string[];
  quantity: string;
  landType: string;
  comment: string;
  caseInfo: string;
  personalInfo?: PersonalInfo[];
  // Legacy fields for backward compatibility
  name?: string;
  parentName?: string;
  address?: string;
  mobile?: string;
  renewalDate: string;
  inclusionDate?: string;
  inspectionDate?: string;
};

const CreateNothi = ({ mouzaData, editData, onFinishEdit, onSuccess }: {
  mouzaData: Mouja[],
  editData?: EditData,
  onFinishEdit?: () => void
  onSuccess?: () => void
}) => {
  const router = useRouter();
  const [editId, setEditId] = useState<string>('');
  const [moujaId, setMouja] = useState<string>('');
  const [partNo, setPartNo] = useState<string>('');
  const [caseNo, setCaseNo] = useState<string>('');
  const [khotianNo, setKhotianNo] = useState<string[]>([]);
  const [lineNo, setLineNo] = useState<string[]>([]);
  const [quantity, setQuantity] = useState<string>('');
  const [landType, setLandType] = useState<string>('');
  const [comment, setComment] = useState<string>('');
  const [caseInfo, setCaseInfo] = useState<string>('');
  const [personalInfo, setPersonalInfo] = useState<PersonalInfo[]>([
    { name: '', parentName: '', address: '', mobile: '' }
  ]);
  const [renewalDate, setRenewalDate] = useState<string>('');
  const [inclusionDate, setInclusionDate] = useState<string>('');
  const [inspectionDate, setInspectionDate] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [errors, setErrors] = useState<{ moujaId?: boolean; partNo?: boolean; lineNo?: boolean; quantity?: boolean; landType?: boolean }>({});

  const moujaRef = useRef<HTMLDivElement>(null);
  const partNoRef = useRef<HTMLDivElement>(null);
  const lineNoRef = useRef<HTMLDivElement>(null);
  const quantityRef = useRef<HTMLDivElement>(null);
  const landTypeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (editData) {
      console.log('Edit Data:', editData);
      // Set form values based on editData
      if (editData.id) {
        setIsEditing(true);
      }
      setEditId(editData.id || '');
      setMouja(editData.moujaId || '');
      setPartNo(editData.partNo || '');
      setCaseNo(editData.caseNo || '');
      setKhotianNo(editData.khotianNo || []); // Ensure it's always an array
      setLineNo(editData.lineNo || []);       // Ensure it's always an array
      setQuantity(editData.quantity || '');
      setLandType(editData.landType || '');
      setComment(editData.comment || '');
      setCaseInfo(editData.caseInfo || '');
      setRenewalDate(editData.renewalDate || '');
      setInclusionDate(editData.inclusionDate || '');
      setInspectionDate(editData.inspectionDate || '');

      // Handle personal info - check if we have the new structure or legacy fields
      if (editData.personalInfo && editData.personalInfo.length > 0) {
        setPersonalInfo(editData.personalInfo);
      } else if (editData.name || editData.parentName || editData.address || editData.mobile) {
        // Convert legacy single person data to new structure
        setPersonalInfo([{
          name: editData.name || '',
          parentName: editData.parentName || '',
          address: editData.address || '',
          mobile: editData.mobile || ''
        }]);
      } else {
        setPersonalInfo([{ name: '', parentName: '', address: '', mobile: '' }]);
      }
    }
  }, [editData]);

  const validateForm = (): boolean => {
    const newErrors: { moujaId?: boolean; partNo?: boolean; lineNo?: boolean; quantity?: boolean; landType?: boolean } = {};
    if (!moujaId) newErrors.moujaId = true;
    if (!partNo.trim()) newErrors.partNo = true;
    if (!lineNo.length) newErrors.lineNo = true;
    if (!quantity.trim()) newErrors.quantity = true;
    if (!landType.trim()) newErrors.landType = true;
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) {
      if (newErrors.moujaId) moujaRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      else if (newErrors.partNo) partNoRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      else if (newErrors.lineNo) lineNoRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      else if (newErrors.quantity) quantityRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      else if (newErrors.landType) landTypeRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return false;
    }
    return true;
  };

  async function createNothiHandler() {
    if (!validateForm()) return;
    setIsSubmitting(true)

    try {
      const data = await createNothi({
        moujaId,
        partNo,
        caseInfo,
        caseNo,
        khotianNo: khotianNo.join(','),
        landType,
        lineNo: lineNo.join(','),
        comment,
        personalInfo: personalInfo.filter(person =>
          person.name.trim() || person.parentName.trim() || person.address.trim() || person.mobile.trim()
        ),
        quantity,
        renewalDate,
        inclusionDate,
        inspectionDate,
      });

      if (data.success) {
        toast.success(data.message);
        onSuccess ? onSuccess() : router.refresh();
        setMouja('');
        setPartNo('');
        setCaseNo('');
        setKhotianNo([]);
        setLineNo([]);
        setQuantity('');
        setLandType('');
        setComment('');
        setCaseInfo('');
        setPersonalInfo([{ name: '', parentName: '', address: '', mobile: '' }]);
        setRenewalDate('');
        setInclusionDate('');
        setInspectionDate('');
      } else {
        toast.error(data.message || 'নথি সংরক্ষণ করতে ব্যর্থ হয়েছে!');
      }
    } catch (err) {
      console.error(err);
      toast.error('নথি সংরক্ষণের সময় একটি ত্রুটি ঘটেছে!');
    }
    finally {
      setIsSubmitting(false);
    }
  }


  async function updateNothiHandler() {
    if (!validateForm()) return;
    setIsSubmitting(true);

    try {
      // Call the updateNothi action
      const data = await updateNothi({
        id: editId,
        moujaId,
        partNo,
        caseNo,
        khotianNo: khotianNo.join(','), // Convert array to comma-separated string
        lineNo: lineNo.join(','),       // Convert array to comma-separated string
        quantity,
        landType,
        comment,
        caseInfo,
        personalInfo: personalInfo.filter(person =>
          person.name.trim() || person.parentName.trim() || person.address.trim() || person.mobile.trim()
        ),
        renewalDate,
        inclusionDate,
        inspectionDate,
        status: 'ACTIVE', // Use the existing status or default to ACTIVE
      });

      if (data.success) {
        toast.success('নথি সফলভাবে আপডেট হয়েছে!');
        router.refresh(); // Refresh the page or data
        resetForm(); // Reset the form
        if (onFinishEdit) onFinishEdit(); // Clear editData
        setIsEditing(false); // Reset editing state
      } else {
        toast.error(data.message || 'নথি আপডেট করতে ব্যর্থ হয়েছে!');
      }
    } catch (err) {
      console.error(err);
      toast.error('নথি আপডেট করার সময় একটি ত্রুটি ঘটেছে!');
    } finally {
      setIsSubmitting(false);
    }
  }


  const resetForm = () => {
    setIsEditing(false);
    setErrors({});
    setEditId("")
    setMouja("")
    setPartNo("")
    setCaseNo("")
    setKhotianNo([])
    setLineNo([])
    setQuantity("")
    setLandType("")
    setComment("")
    setCaseInfo("")
    setPersonalInfo([{ name: '', parentName: '', address: '', mobile: '' }])
    setRenewalDate("")
    setInclusionDate("")
    setInspectionDate("")
  }

  // Count how many fields are filled
  const filledFields = [
    moujaId,
    partNo,
    caseNo,
    khotianNo.length > 0 ? 'ok' : '',
    lineNo.length > 0 ? 'ok' : '',
    quantity,
    landType,
    renewalDate,
    personalInfo.some(person =>
      person.name.trim() || person.parentName.trim() || person.address.trim() || person.mobile.trim()
    ) ? 'ok' : '',
  ];
  const filledCount = filledFields.filter(Boolean).length;
  const progress = Math.round((filledCount / filledFields.length) * 100);

  return (
    <div className="min-h-screen bg-gradient-to-br p-2">
      <div className="mx-auto space-y-8">

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information */}
            <div ref={partNoRef} className="space-y-3">
              <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                <Hash className="h-4 w-4 text-blue-500" />
                খন্ড নং
                <span className="text-red-500 ml-0.5">*</span>
              </Label>
              <Input
                value={partNo || ''}
                onChange={(e) => { setPartNo(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, partNo: false })); }}
                placeholder="খন্ড নং লিখুন..."
                className={`h-12 border-slate-300 focus:border-blue-500 focus:ring-blue-500${errors.partNo ? ' border-red-500 ring-1 ring-red-500' : ''}`}
              />
              {errors.partNo && <p className="text-red-500 text-xs">খন্ড নং প্রদান করুন</p>}
            </div>
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-blue-200 to-indigo-200 text-blue-800 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  মৌলিক তথ্য
                </CardTitle>
                <CardDescription className="text-blue-800">নথির প্রাথমিক তথ্যাদি প্রদান করুন</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div ref={moujaRef} className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <MapPin className="h-4 w-4 text-blue-500" />
                    মৌজা
                    <span className="text-red-500 ml-0.5">*</span>
                  </Label>
                  <div className={errors.moujaId ? 'rounded-md ring-2 ring-red-500' : ''}>
                    <MoujaSelect mouzaData={mouzaData} value={moujaId} setValue={(val: string) => { setMouja(val); if (val) setErrors(prev => ({ ...prev, moujaId: false })); }} />
                  </div>
                  {errors.moujaId && <p className="text-red-500 text-xs">মৌজা নির্বাচন করুন</p>}
                </div>

                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Hash className="h-4 w-4 text-blue-500" />
                    কেস নথি নং
                  </Label>
                  <Input
                    value={caseNo || ''}
                    onChange={(e) => setCaseNo(e.target.value)}
                    placeholder="কেস নথি নং লিখুন..."
                    className="h-12 border-slate-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Hash className="h-4 w-4 text-blue-500" />
                      খতিয়ান নং
                    </Label>
                    <InputTags value={khotianNo || []} onChange={setKhotianNo} />
                  </div>

                  <div ref={lineNoRef} className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Hash className="h-4 w-4 text-blue-500" />
                      দাগ নং
                      <span className="text-red-500 ml-0.5">*</span>
                    </Label>
                    <div className={errors.lineNo ? 'rounded-md ring-2 ring-red-500' : ''}>
                      <InputTags value={lineNo || []} onChange={(val) => { setLineNo(val); if (val.length) setErrors(prev => ({ ...prev, lineNo: false })); }} />
                    </div>
                    {errors.lineNo && <p className="text-red-500 text-xs">দাগ নং প্রদান করুন</p>}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Land Details */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-indigo-200 to-purple-200 text-purple-700 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Scale className="h-5 w-5" />
                  জমির বিবরণ
                </CardTitle>
                <CardDescription className="text-blue-800">জমি সংক্রান্ত বিস্তারিত তথ্য</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <div ref={quantityRef} className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Scale className="h-4 w-4 text-indigo-500" />
                      পরিমাণ
                      <span className="text-red-500 ml-0.5">*</span>
                    </Label>
                    <Input
                      value={quantity}
                      onChange={(e) => { setQuantity(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, quantity: false })); }}
                      placeholder="জমির পরিমাণ লিখুন..."
                      className={`h-12 border-slate-300 focus:border-green-500 focus:ring-green-500${errors.quantity ? ' border-red-500 ring-1 ring-red-500' : ''}`}
                    />
                    {errors.quantity && <p className="text-red-500 text-xs">পরিমাণ প্রদান করুন</p>}
                  </div>

                  <div ref={landTypeRef} className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <MapPin className="h-4 w-4 text-indigo-500" />
                      জমির শ্রেণী
                      <span className="text-red-500 ml-0.5">*</span>
                    </Label>
                    <Input
                      value={landType}
                      onChange={(e) => { setLandType(e.target.value); if (e.target.value.trim()) setErrors(prev => ({ ...prev, landType: false })); }}
                      placeholder="জমির শ্রেণী লিখুন..."
                      className={`h-12 border-slate-300 focus:border-green-500 focus:ring-green-500${errors.landType ? ' border-red-500 ring-1 ring-red-500' : ''}`}
                    />
                    {errors.landType && <p className="text-red-500 text-xs">জমির শ্রেণী প্রদান করুন</p>}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Calendar className="h-4 w-4 text-indigo-500" />
                    সর্বশেষ লীজ প্রদান/নবায়নের সাল
                  </Label>
                  <Input
                    value={renewalDate}
                    onChange={(e) => setRenewalDate(e.target.value)}
                    placeholder="বাংলা সন লিখুন..."
                    className="h-12 border-slate-300 focus:border-green-500 focus:ring-green-500"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Personal Information */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-purple-200 to-indigo-200 text-purple-700 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  ব্যক্তিগত তথ্য
                </CardTitle>
                <CardDescription className="text-blue-800">লীজ গ্রহীতার / অবৈধ দখলদাররে বিস্তারিত তথ্য</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-4">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <User className="h-4 w-4 text-purple-500" />
                    লীজ গ্রহীতার / অবৈধ দখলদাররে তথ্য
                  </Label>
                  <PersonalInfoManager
                    personalInfo={personalInfo}
                    onChange={setPersonalInfo}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Additional Information */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader className="py-4 bg-gradient-to-r from-orange-100 to-red-100 text-orange-700 rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  অতিরিক্ত তথ্য
                </CardTitle>
                <CardDescription className="text-orange-800">মামলা ও মন্তব্য সংক্রান্ত তথ্য</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Calendar className="h-4 w-4 text-orange-500" />
                      অন্তরভুক্তির তারিখ
                    </Label>
                    <DatePickerField
                      value={inclusionDate}
                      onChange={setInclusionDate}
                      placeholder="দিন/মাস/বছর নির্বাচন করুন"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                      <Calendar className="h-4 w-4 text-orange-500" />
                      পরিদর্শনের তারিখ
                    </Label>
                    <DatePickerField
                      value={inspectionDate}
                      onChange={setInspectionDate}
                      placeholder="দিন/মাস/বছর নির্বাচন করুন"
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <Scale className="h-4 w-4 text-orange-500" />
                    মামলা সংক্রান্ত তথ্য
                  </Label>
                  <Input
                    value={caseInfo}
                    onChange={(e) => setCaseInfo(e.target.value)}
                    placeholder="মামলা সংক্রান্ত তথ্য লিখুন..."
                    className="h-12 border-slate-300 focus:border-orange-500 focus:ring-orange-500"
                  />
                </div>
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                    <MessageSquare className="h-4 w-4 text-orange-500" />
                    মন্তব্য
                  </Label>
                  <Input
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="মন্তব্য লিখুন..."
                    className="h-12 border-slate-300 focus:border-orange-500 focus:ring-orange-500"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6 flex flex-col sticky top-4 justify-start">
            {/* Progress Card */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-gradient-to-br from-sky-600 to-cyan-700 text-white">
              <CardContent className="p-6">
                <div className="text-center space-y-4">
                  <CheckCircle2 className="h-12 w-12 mx-auto text-white/80" />
                  <h3 className="text-lg font-semibold">ফর্ম অগ্রগতি</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>সম্পূর্ণতা</span>
                      <span>{progress}%</span>
                    </div>
                    <div className="w-full bg-white/20 rounded-full h-2">
                      <div
                        className="bg-white h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <Card className="py-0 mb-8 gap-0 border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6 space-y-4">
                <Button
                  onClick={isEditing ? updateNothiHandler : createNothiHandler}
                  disabled={isSubmitting}
                  className={`w-full h-12 text-white font-semibold shadow-lg transition-all duration-200
                  ${isEditing
                      ? 'bg-yellow-600 hover:bg-yellow-700'
                      : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-700 hover:to-teal-700'
                    }`}
                >
                  {isSubmitting ? (
                    <div className="flex items-center gap-2">
                      <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      {isEditing ? "আপডেট হচ্ছে..." : "সংরক্ষণ হচ্ছে..."}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Save className="h-4 w-4" />
                      {isEditing ? "নথি আপডেট করুন" : "নথি সংরক্ষণ করুন"}
                    </div>
                  )}
                </Button>

                <Button
                  onClick={resetForm}
                  variant="outline"
                  className="w-full h-12 border-slate-300 text-slate-700 hover:bg-slate-50 transition-all duration-200"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  ফর্ম রিসেট করুন
                </Button>
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-slate-800">
                  <Sparkles className="h-5 w-5 text-yellow-500" />
                  দ্রুত টিপস
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <div className="h-2 w-2 bg-blue-500 rounded-full mt-2"></div>
                  <p className="text-sm text-slate-700">খতিয়ান এবং দাগ নং টাইপ করে Enter চাপুন</p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <div className="h-2 w-2 bg-blue-500 rounded-full mt-2"></div>
                  <p className="text-sm text-slate-700">প্রয়োজনীয় ক্ষেত্রগুলো পূরণ করুন</p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <div className="h-2 w-2 bg-green-500 rounded-full mt-2"></div>
                  <p className="text-sm text-slate-700">মোবাইল নম্বর সঠিকভাবে লিখুন</p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
                  <div className="h-2 w-2 bg-purple-500 rounded-full mt-2"></div>
                  <p className="text-sm text-slate-700">একাধিক দাগ/খতিয়ান নং যোগ করতে পারেন</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateNothi;
