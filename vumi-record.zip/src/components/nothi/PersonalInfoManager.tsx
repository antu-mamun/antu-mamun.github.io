'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, User } from 'lucide-react';

export type PersonalInfo = {
    name: string;
    parentName: string;
    address: string;
    mobile: string;
};

type PersonalInfoManagerProps = {
    personalInfo: PersonalInfo[];
    onChange: (personalInfo: PersonalInfo[]) => void;
};

export default function PersonalInfoManager({ personalInfo, onChange }: PersonalInfoManagerProps) {
    const addPersonalInfo = () => {
        const newPersonalInfo = [...personalInfo, { name: '', parentName: '', address: '', mobile: '' }];
        onChange(newPersonalInfo);
    };

    const removePersonalInfo = (index: number) => {
        if (personalInfo.length > 1) {
            const newPersonalInfo = personalInfo.filter((_, i) => i !== index);
            onChange(newPersonalInfo);
        }
    };

    const updatePersonalInfo = (index: number, field: keyof PersonalInfo, value: string) => {
        const newPersonalInfo = personalInfo.map((item, i) =>
            i === index ? { ...item, [field]: value } : item
        );
        onChange(newPersonalInfo);
    };

    return (
        <div className="space-y-4">
            {personalInfo.map((person, index) => (
                <Card key={index} className="gap-0 border-dashed border-2 border-purple-200 bg-purple-50/30">
                    <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                            <CardTitle className="flex items-center gap-2 text-sm font-semibold text-purple-700">
                                <User className="h-4 w-4" />
                                ব্যক্তি {index + 1}
                                {index === 0 && (
                                    <Badge variant="secondary" className="bg-purple-100 text-purple-800 text-xs">
                                        প্রধান
                                    </Badge>
                                )}
                            </CardTitle>
                            {personalInfo.length > 1 && (
                                <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => removePersonalInfo(index)}
                                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                >
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            )}
                        </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
                            <div>
                                <label className="text-xs font-medium text-slate-600 mb-1 block">নাম</label>
                                <Input
                                    value={person.name}
                                    onChange={(e) => updatePersonalInfo(index, 'name', e.target.value)}
                                    placeholder="নাম লিখুন"
                                    className="h-10 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                                />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-slate-600 mb-1 block">পিতার নাম</label>
                                <Input
                                    value={person.parentName}
                                    onChange={(e) => updatePersonalInfo(index, 'parentName', e.target.value)}
                                    placeholder="পিতার নাম লিখুন"
                                    className="h-10 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                                />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-slate-600 mb-1 block">ঠিকানা</label>
                                <Input
                                    value={person.address}
                                    onChange={(e) => updatePersonalInfo(index, 'address', e.target.value)}
                                    placeholder="ঠিকানা লিখুন"
                                    className="h-10 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                                />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-slate-600 mb-1 block">মোবাইল নম্বর</label>
                                <Input
                                    value={person.mobile}
                                    onChange={(e) => updatePersonalInfo(index, 'mobile', e.target.value)}
                                    placeholder="মোবাইল নম্বর লিখুন"
                                    className="h-10 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                                />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            ))}

            <div className="flex justify-center pt-2">
                <Button
                    type="button"
                    variant="outline"
                    onClick={addPersonalInfo}
                    className="border-dashed border-2 border-purple-300 text-purple-700 hover:bg-purple-50 transition-colors"
                >
                    <Plus className="h-4 w-4 mr-2" />
                    নতুন ব্যক্তি যোগ করুন
                </Button>
            </div>
        </div>
    );
}
