'use server';

import { Status } from '@/generated/prisma';
import { prisma } from '@/lib/db';

export async function createNothi({
  moujaId,
  partNo,
  caseNo,
  khotianNo,
  lineNo,
  quantity,
  landType,
  comment,
  caseInfo,
  personalInfo,
  renewalDate,
  inclusionDate,
  inspectionDate,
  status,
}: {
  moujaId: string;
  partNo: string;
  caseNo: string;
  khotianNo: string;
  lineNo: string;
  quantity: string;
  landType: string;
  comment: string;
  caseInfo: string;
  personalInfo: Array<{
    name: string;
    parentName: string;
    address: string;
    mobile: string;
  }>;
  renewalDate: string;
  inclusionDate?: string;
  inspectionDate?: string;
  status?: Status;
}) {
  try {
    const nothi = await prisma.nothi.create({
      data: {
        moujaId,
        partNo,
        caseNo,
        khotianNo,
        lineNo,
        quantity,
        landType,
        comment,
        caseInfo,
        personalInfo: JSON.stringify(personalInfo),
        renewalDate,
        inclusionDate: inclusionDate || '',
        inspectionDate: inspectionDate || '',
        status: status || 'ACTIVE',
      },
    });

    return {
      success: true,
      data: nothi,
      message: 'Nothi created successfully!',
    };
  } catch (err) {
    console.error('Error data ', err);
    return {
      success: false,
      message: 'Error on creating nothi!',
    };
  }
}

export async function updateNothi({
  id,
  moujaId,
  partNo,
  caseNo,
  khotianNo,
  lineNo,
  quantity,
  landType,
  comment,
  caseInfo,
  personalInfo,
  renewalDate,
  inclusionDate,
  inspectionDate,
  status,
}: {
  id: string;
  moujaId: string;
  partNo: string;
  caseNo: string;
  khotianNo: string;
  lineNo: string;
  quantity: string;
  landType: string;
  comment: string;
  caseInfo: string;
  personalInfo: Array<{
    name: string;
    parentName: string;
    address: string;
    mobile: string;
  }>;
  renewalDate: string;
  inclusionDate?: string;
  inspectionDate?: string;
  status?: Status;
}) {
  try {
    const nothi = await prisma.nothi.update({
      where: { id },
      data: {
        moujaId,
        partNo,
        caseNo,
        khotianNo,
        lineNo,
        quantity,
        landType,
        comment,
        caseInfo,
        personalInfo: JSON.stringify(personalInfo),
        renewalDate,
        inclusionDate: inclusionDate || '',
        inspectionDate: inspectionDate || '',
        status: status || 'ACTIVE',
      },
    });

    return {
      success: true,
      data: nothi,
      message: 'Nothi updated successfully!',
    };
  } catch (err) {
    console.error('Error data ', err);
    return {
      success: false,
      message: 'Error on updating nothi!',
    };
  }
}

export async function deleteNothi(id: string) {
  try {
    // Use Prisma to delete the nothi record by its ID
    const nothi = await prisma.nothi.delete({
      where: { id },
    });

    return {
      success: true,
      data: nothi,
      message: 'Nothi deleted successfully!',
    };
  } catch (err) {
    console.error('Error data ', err); // helpful during debugging
    return {
      success: false,
      message: 'Error on deleting nothi!',
    };
  }
}

