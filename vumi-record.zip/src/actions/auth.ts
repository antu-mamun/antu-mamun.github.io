'use server';

import { prisma } from '@/lib/db';
import { cookies } from 'next/headers';
import { verifyPassword, generateToken, verifyToken, validateEnvVars } from '@/lib/auth';

// Initialize environment validation
validateEnvVars();

export type LoginInput = {
  email: string;
  password: string;
};

export type AuthUser = {
  id: string;
  name: string;
  email: string;
  role: string;
  photo: string;
};

export async function login(input: LoginInput) {
  try {
    const { email, password } = input;

    // Validate input
    if (!email || !password) {
      return { 
        success: false, 
        message: 'ইমেইল এবং পাসওয়ার্ড উভয়ই প্রয়োজন।' 
      };
    }

    // Find user by email
    const user = await prisma.user.findFirst({
      where: {
        email: email.toLowerCase().trim(),
      },
    });

    if (!user) {
      return { 
        success: false, 
        message: 'ভুল ইমেইল বা পাসওয়ার্ড।' 
      };
    }

    // Verify password
    const isPasswordValid = await verifyPassword(password, user.password);
    
    if (!isPasswordValid) {
      return { 
        success: false, 
        message: 'ভুল ইমেইল বা পাসওয়ার্ড।' 
      };
    }

    // Generate JWT token
    const token = generateToken({
      id: user.id,
      email: user.email,
      role: user.role
    });

    // Set secure cookies
    const cookieStore = await cookies();
    
    // Set auth token (httpOnly for security)
    cookieStore.set('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60, // 7 days
      path: '/'
    });
    
    // Set user info for client-side access
    cookieStore.set('user', user.id, {
      maxAge: 7 * 24 * 60 * 60, // 7 days
      path: '/'
    });
    
    cookieStore.set('user_vumi_role', user.role, {
      maxAge: 7 * 24 * 60 * 60, // 7 days
      path: '/'
    });

    return { 
      success: true, 
      message: 'সফলভাবে লগইন হয়েছে!',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        photo: user.photo
      }
    };
  } catch (error) {
    console.error('Login error:', error);
    return { 
      success: false, 
      message: 'লগইন করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।' 
    };
  }
}

export async function logout() {
  try {
    const cookieStore = await cookies();
    
    // Clear all auth-related cookies
    cookieStore.delete('auth_token');
    cookieStore.delete('user');
    cookieStore.delete('user_vumi_role');
    
    return { 
      success: true, 
      message: 'সফলভাবে লগআউট হয়েছে।' 
    };
  } catch (error) {
    console.error('Logout error:', error);
    return { 
      success: false, 
      message: 'লগআউট করতে সমস্যা হয়েছে।' 
    };
  }
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('auth_token')?.value;
    
    if (!token) {
      return null;
    }
    
    // Verify token
    const tokenData = verifyToken(token);
    if (!tokenData) {
      // Clear invalid cookies
      cookieStore.delete('auth_token');
      cookieStore.delete('user');
      cookieStore.delete('user_vumi_role');
      return null;
    }
    
    // Get fresh user data from database
    const user = await prisma.user.findUnique({
      where: { id: tokenData.id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        photo: true,
      }
    });
    
    if (!user) {
      // Clear cookies if user no longer exists
      cookieStore.delete('auth_token');
      cookieStore.delete('user');
      cookieStore.delete('user_vumi_role');
      return null;
    }
    
    return user;
  } catch (error) {
    console.error('Get current user error:', error);
    return null;
  }
}

export async function validateAuth(): Promise<{ isValid: boolean; user?: AuthUser }> {
  try {
    const user = await getCurrentUser();
    return {
      isValid: !!user,
      user: user || undefined
    };
  } catch (error) {
    console.error('Validate auth error:', error);
    return { isValid: false };
  }
}
