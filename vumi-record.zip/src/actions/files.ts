'use server';

import { prisma } from '@/lib/db';
import { Status } from '@/generated/prisma';
import { writeFile, unlink } from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { assertUploadDomain } from '@/lib/upload-domain-guard';

export type FileUploadType = {
  id: string;
  name: string;
  originalName: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  filePath: string;
  status: 'ACTIVE' | 'INACTIVE' | 'DELETED';
  createdAt: Date;
  updatedAt: Date;
};

export async function uploadFile(formData: FormData) {
  // ── Domain enforcement ────────────────────────────────────────────────────
  const domainCheck = await assertUploadDomain();
  if (!domainCheck.allowed) {
    return { success: false, message: domainCheck.message };
  }

  try {
    const file = formData.get('file') as File;
    const name = formData.get('name') as string;

    // Validation checks
    if (!file || !name) {
      return { success: false, message: 'ফাইল এবং নাম উভয়ই প্রয়োজন।' };
    }

    // Check file size (10MB limit)
    const maxSize = 10 * 1024 * 1024; // 10MB in bytes
    if (file.size > maxSize) {
      return { 
        success: false, 
        message: 'ফাইলের আকার ১০ এমবি এর বেশি হতে পারে না।' 
      };
    }

    // Check if file is empty
    if (file.size === 0) {
      return { 
        success: false, 
        message: 'খালি ফাইল আপলোড করা যাবে না।' 
      };
    }

    // Validate file name length
    if (name.trim().length < 3) {
      return { 
        success: false, 
        message: 'ফাইলের নাম কমপক্ষে ৩ অক্ষরের হতে হবে।' 
      };
    }

    if (name.trim().length > 100) {
      return { 
        success: false, 
        message: 'ফাইলের নাম ১০০ অক্ষরের বেশি হতে পারে না।' 
      };
    }

    // Check allowed file types
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'image/jpeg',
      'image/jpg',
      'image/png',
      'image/gif',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv'
    ];

    if (!allowedTypes.includes(file.type)) {
      return { 
        success: false, 
        message: 'অনুমতিপ্রাপ্ত ফাইল ধরন: PDF, Word, Text, Image, Excel, CSV।' 
      };
    }

    // Create uploads directory if it doesn't exist
    const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
    
    // Generate unique filename
    const fileExtension = path.extname(file.name);
    const fileName = `${uuidv4()}${fileExtension}`;
    const filePath = `/uploads/${fileName}`;
    const fullPath = path.join(uploadsDir, fileName);

    // Convert file to buffer and save
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    await writeFile(fullPath, buffer);

    // Save file info to database
    const fileRecord = await prisma.fileUpload.create({
      data: {
        name: name.trim(),
        originalName: file.name,
        fileName,
        fileSize: file.size,
        mimeType: file.type,
        filePath,
        status: Status.ACTIVE,
      },
    });

    return { 
      success: true, 
      data: fileRecord, 
      message: 'ফাইল সফলভাবে আপলোড হয়েছে!' 
    };
  } catch (error) {
    console.error('Error uploading file:', error);
    
    // Handle specific errors
    if (error instanceof Error) {
      if (error.message.includes('Body exceeded')) {
        return { 
          success: false, 
          message: 'ফাইলের আকার অনেক বড়। দয়া করে ১০ এমবি এর ছোট ফাইল আপলোড করুন।' 
        };
      }
      if (error.message.includes('ENOSPC')) {
        return { 
          success: false, 
          message: 'সার্ভারে পর্যাপ্ত স্টোরেজ নেই।' 
        };
      }
      if (error.message.includes('EACCES')) {
        return { 
          success: false, 
          message: 'ফাইল সংরক্ষণের অনুমতি নেই।' 
        };
      }
    }
    
    return { 
      success: false, 
      message: 'ফাইল আপলোড করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।' 
    };
  }
}

export async function updateFileName({
  id,
  name,
}: {
  id: string;
  name: string;
}) {
  try {
    // Validation checks
    if (!name || !name.trim()) {
      return { success: false, message: 'ফাইলের নাম প্রয়োজন।' };
    }

    if (name.trim().length < 3) {
      return { 
        success: false, 
        message: 'ফাইলের নাম কমপক্ষে ৩ অক্ষরের হতে হবে।' 
      };
    }

    if (name.trim().length > 100) {
      return { 
        success: false, 
        message: 'ফাইলের নাম ১০০ অক্ষরের বেশি হতে পারে না।' 
      };
    }

    const updatedFile = await prisma.fileUpload.update({
      where: { id },
      data: { 
        name: name.trim(),
        updatedAt: new Date(),
      },
    });

    return { 
      success: true, 
      data: updatedFile, 
      message: 'ফাইলের নাম সফলভাবে আপডেট হয়েছে!' 
    };
  } catch (error) {
    console.error('Error updating file name:', error);
    
    if (error instanceof Error) {
      if (error.message.includes('Record to update not found')) {
        return { success: false, message: 'ফাইল খুঁজে পাওয়া যায়নি।' };
      }
    }
    
    return { success: false, message: 'ফাইলের নাম আপডেট করতে ব্যর্থ।' };
  }
}

export async function deleteFile(id: string) {
  try {
    if (!id) {
      return { success: false, message: 'ফাইল আইডি প্রয়োজন।' };
    }

    const file = await prisma.fileUpload.findUnique({
      where: { id },
    });

    if (!file) {
      return { success: false, message: 'ফাইল খুঁজে পাওয়া যায়নি।' };
    }

    // Delete physical file
    try {
      const fullPath = path.join(process.cwd(), 'public', file.filePath);
      await unlink(fullPath);
    } catch (fileError) {
      console.warn('Could not delete physical file:', fileError);
      // Continue with database deletion even if physical file deletion fails
    }

    // Delete database record
    await prisma.fileUpload.delete({
      where: { id },
    });

    return { success: true, message: 'ফাইল সফলভাবে মুছে ফেলা হয়েছে!' };
  } catch (error) {
    console.error('Error deleting file:', error);
    
    if (error instanceof Error) {
      if (error.message.includes('Record to delete does not exist')) {
        return { success: false, message: 'ফাইল খুঁজে পাওয়া যায়নি।' };
      }
    }
    
    return { success: false, message: 'ফাইল মুছতে ব্যর্থ।' };
  }
}

export async function getFiles({
  search = '',
  startDate,
  endDate,
  page = 1,
  limit = 10,
}: {
  search?: string;
  startDate?: Date;
  endDate?: Date;
  page?: number;
  limit?: number;
} = {}) {
  try {
    // Start with basic filter
    const where: any = {
      status: Status.ACTIVE,
    };

    // Add search filter only if search term exists and is valid
    if (search && typeof search === 'string' && search.trim().length > 0) {
      const searchTerm = search.trim();
      where.OR = [
        { name: { contains: searchTerm } },
        { originalName: { contains: searchTerm } },
      ];
    }

    // Add date range filter with proper validation
    if (startDate && endDate) {
      // Ensure dates are Date objects
      const start = startDate instanceof Date ? startDate : new Date(startDate);
      const end = endDate instanceof Date ? endDate : new Date(endDate);
      
      where.createdAt = {
        gte: start,
        lte: end,
      };
    } else if (startDate) {
      const start = startDate instanceof Date ? startDate : new Date(startDate);
      where.createdAt = {
        gte: start,
      };
    } else if (endDate) {
      const end = endDate instanceof Date ? endDate : new Date(endDate);
      where.createdAt = {
        lte: end,
      };
    }

    console.log('Prisma query where:', JSON.stringify(where, null, 2));

    const [files, total] = await Promise.all([
      prisma.fileUpload.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.fileUpload.count({ where }),
    ]);

    console.log(`Found ${files.length} files out of ${total} total`);

    return {
      success: true,
      data: {
        files,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit),
        },
      },
    };
  } catch (error) {
    console.error('Error fetching files:', error);
    
    // More detailed error logging
    if (error instanceof Error) {
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
    }
    
    return { 
      success: false, 
      message: 'ফাইল তালিকা লোড করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।' 
    };
  }
}

export async function getFileById(id: string) {
  try {
    const file = await prisma.fileUpload.findUnique({
      where: { id },
    });

    if (!file) {
      return { success: false, message: 'File not found.' };
    }

    return { success: true, data: file };
  } catch (error) {
    console.error('Error fetching file:', error);
    return { success: false, message: 'Failed to fetch file.' };
  }
}

export async function getSecureFileData(id: string) {
  try {
    // Get user from cookies to verify authentication
    const { cookies } = await import('next/headers');
    const cookieStore = await cookies();
    const user = cookieStore.get('user')?.value;
    
    if (!user) {
      return { 
        success: false, 
        message: 'Unauthorized: You must be logged in to access files.' 
      };
    }

    const file = await prisma.fileUpload.findUnique({
      where: { 
        id,
        status: Status.ACTIVE 
      },
    });

    if (!file) {
      return { 
        success: false, 
        message: 'File not found or has been deleted.' 
      };
    }

    // Return file metadata for secure access
    return { 
      success: true, 
      data: {
        id: file.id,
        name: file.name,
        originalName: file.originalName,
        fileName: file.fileName,
        mimeType: file.mimeType,
        fileSize: file.fileSize,
        filePath: file.filePath
      }
    };
  } catch (error) {
    console.error('Error fetching secure file data:', error);
    return { 
      success: false, 
      message: 'Failed to fetch file data.' 
    };
  }
}
