import { randomBytes } from 'crypto';

/**
 * Generate a secure JWT secret
 */
export async function generateSecureJWTSecret() {
  try {
    // Generate a secure random secret (64 bytes = 512 bits)
    const secret = randomBytes(64).toString('hex');
    
    return {
      success: true,
      secret: secret,
      message: 'Secure JWT secret generated successfully'
    };
  } catch (error) {
    console.error('Error generating JWT secret:', error);
    return {
      success: false,
      message: 'Failed to generate JWT secret: ' + (error instanceof Error ? error.message : 'Unknown error')
    };
  }
}
