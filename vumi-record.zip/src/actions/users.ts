'use server';

import { prisma } from '@/lib/db';
import { Role } from '@/generated/prisma';
import { hashPassword, validatePassword } from '@/lib/auth';

export type User = {
    id: string;
    name: string;
    email: string;
    photo: string;
    role: 'ADMIN' | 'EDITOR' | 'USER';
};

export type CreateUserInput = {
  name: string;
  email: string;
  password: string;
  photo: string;
  role: 'ADMIN' | 'EDITOR' | 'USER';
};

export type UpdateUserInput = {
  id: string;
  name: string;
  email: string;
  password?: string; // Optional for updates
  photo: string;
  role: 'ADMIN' | 'EDITOR' | 'USER';
};

export async function createUser(input: CreateUserInput) {
  try {
    const { name, email, password, photo, role } = input;

    // Validate input
    if (!name || !email || !password || !role) {
      return { 
        success: false, 
        message: 'নাম, ইমেইল, পাসওয়ার্ড এবং ভূমিকা সবগুলো প্রয়োজন।' 
      };
    }

    // Validate password
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.isValid) {
      return { 
        success: false, 
        message: `পাসওয়ার্ড সমস্যা: ${passwordValidation.message}` 
      };
    }

    // Check if user already exists
    const existingUser = await prisma.user.findFirst({
      where: { email: email.toLowerCase().trim() }
    });

    if (existingUser) {
      return { 
        success: false, 
        message: 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট রয়েছে।' 
      };
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user
    const user = await prisma.user.create({
      data: {
        name: name.trim(),
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        photo: photo || '',
        role: role as Role,
      },
      select: {
        id: true,
        name: true,
        email: true,
        photo: true,
        role: true,
      }
    });

    return { 
      success: true, 
      data: user, 
      message: 'ব্যবহারকারী সফলভাবে তৈরি হয়েছে!' 
    };
  } catch (error: any) {
    console.error('Error creating user:', error);
    
    // Handle unique constraint violation
    if (error.code === 'P2002' && error.meta?.target?.includes('email')) {
      return { 
        success: false, 
        message: 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট রয়েছে।' 
      };
    }
    
    return { 
      success: false, 
      message: 'ব্যবহারকারী তৈরি করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।' 
    };
  }
}

export async function updateUser(input: UpdateUserInput) {
  try {
    const { id, name, email, password, photo, role } = input;

    // Validate input
    if (!id || !name || !email || !role) {
      return { 
        success: false, 
        message: 'আইডি, নাম, ইমেইল এবং ভূমিকা সবগুলো প্রয়োজন।' 
      };
    }

    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { id }
    });

    if (!existingUser) {
      return { 
        success: false, 
        message: 'ব্যবহারকারী পাওয়া যায়নি।' 
      };
    }

    // Prepare update data
    const updateData: any = {
      name: name.trim(),
      email: email.toLowerCase().trim(),
      photo: photo || '',
      role: role as Role,
    };

    // If password is provided, validate and hash it
    if (password && password.trim()) {
      const passwordValidation = validatePassword(password);
      if (!passwordValidation.isValid) {
        return { 
          success: false, 
          message: `পাসওয়ার্ড সমস্যা: ${passwordValidation.message}` 
        };
      }
      updateData.password = await hashPassword(password);
    }

    // Update user
    const user = await prisma.user.update({
      where: { id },
      data: updateData,
      select: {
        id: true,
        name: true,
        email: true,
        photo: true,
        role: true,
      }
    });

    return { 
      success: true, 
      data: user, 
      message: 'ব্যবহারকারীর তথ্য সফলভাবে আপডেট হয়েছে!' 
    };
  } catch (error: any) {
    console.error('Error updating user:', error);
    
    // Handle unique constraint violation
    if (error.code === 'P2002' && error.meta?.target?.includes('email')) {
      return { 
        success: false, 
        message: 'এই ইমেইল দিয়ে ইতিমধ্যে অন্য একটি অ্যাকাউন্ট রয়েছে।' 
      };
    }
    
    return { 
      success: false, 
      message: 'ব্যবহারকারীর তথ্য আপডেট করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।' 
    };
  }
}

export async function deleteUser(id: string) {
  try {
    await prisma.user.delete({ where: { id } });
    return { success: true, message: 'User deleted successfully!' };
  } catch (error) {
    console.error('Error deleting user:', error);
    return { success: false, message: 'Failed to delete user.' };
  }
}

export async function getUsers() {
  try {
    const users = await prisma.user.findMany({ orderBy: { name: 'asc' } });
    return { success: true, data: users };
  } catch (error) {
    console.error('Error fetching users:', error);
    return { success: false, data: [], message: 'Failed to fetch users.' };
  }
}