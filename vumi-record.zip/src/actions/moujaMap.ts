'use server';

import { prisma } from '@/lib/db';
import { writeFile, unlink } from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { assertUploadDomain } from '@/lib/upload-domain-guard';

const ALLOWED_TYPES = [
  'application/pdf',
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/gif',
];

const MAX_SIZE = 20 * 1024 * 1024; // 20MB

async function saveFile(file: File): Promise<{
  fileName: string;
  originalName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
} | { error: string }> {
  if (file.size > MAX_SIZE) {
    return { error: 'ফাইলের আকার ২০ এমবি এর বেশি হতে পারে না।' };
  }
  if (!ALLOWED_TYPES.includes(file.type)) {
    return { error: 'অনুমতিপ্রাপ্ত ফাইল ধরন: PDF, JPG, PNG, GIF।' };
  }

  const ext = file.name.split('.').pop() || 'bin';
  const fileName = `mouja_map_${uuidv4()}.${ext}`;
  const uploadDir = path.join(process.cwd(), 'public', 'uploads');
  const bytes = await file.arrayBuffer();
  await writeFile(path.join(uploadDir, fileName), Buffer.from(bytes));

  return {
    fileName,
    originalName: file.name,
    filePath: `/uploads/${fileName}`,
    fileSize: file.size,
    mimeType: file.type,
  };
}

export async function createMoujaMap(formData: FormData) {
  // ── Domain enforcement ────────────────────────────────────────────────────
  const domainCheck = await assertUploadDomain();
  if (!domainCheck.allowed) {
    return { success: false, message: domainCheck.message };
  }

  try {
    const moujaId = formData.get('moujaId') as string;
    const sheetCount = parseInt(formData.get('sheetCount') as string) || 0;
    const file = formData.get('file') as File | null;

    if (!moujaId) {
      return { success: false, message: 'মৌজা নির্বাচন করুন।' };
    }

    let fileData = { fileName: '', originalName: '', filePath: '', fileSize: 0, mimeType: '' };

    if (file && file.size > 0) {
      const result = await saveFile(file);
      if ('error' in result) return { success: false, message: result.error };
      fileData = result;
    }

    const moujaMap = await prisma.moujaMap.create({
      data: {
        moujaId,
        sheetCount,
        ...fileData,
      },
    });

    return { success: true, data: moujaMap, message: 'মৌজা ম্যাপ সফলভাবে সংরক্ষণ হয়েছে!' };
  } catch (err) {
    console.error(err);
    return { success: false, message: 'মৌজা ম্যাপ সংরক্ষণে ত্রুটি হয়েছে!' };
  }
}

export async function updateMoujaMap(formData: FormData) {
  // ── Domain enforcement ────────────────────────────────────────────────────
  const domainCheck = await assertUploadDomain();
  if (!domainCheck.allowed) {
    return { success: false, message: domainCheck.message };
  }

  try {
    const id = formData.get('id') as string;
    const moujaId = formData.get('moujaId') as string;
    const sheetCount = parseInt(formData.get('sheetCount') as string) || 0;
    const file = formData.get('file') as File | null;
    const existingFilePath = formData.get('existingFilePath') as string;

    if (!moujaId) {
      return { success: false, message: 'মৌজা নির্বাচন করুন।' };
    }

    let fileData: Record<string, string | number> = {};

    if (file && file.size > 0) {
      const result = await saveFile(file);
      if ('error' in result) return { success: false, message: result.error };
      fileData = result;

      // Delete old file if it exists
      if (existingFilePath) {
        const oldFilePath = path.join(process.cwd(), 'public', existingFilePath);
        unlink(oldFilePath).catch(() => null);
      }
    }

    const moujaMap = await prisma.moujaMap.update({
      where: { id },
      data: {
        moujaId,
        sheetCount,
        ...fileData,
      },
    });

    return { success: true, data: moujaMap, message: 'মৌজা ম্যাপ সফলভাবে আপডেট হয়েছে!' };
  } catch (err) {
    console.error(err);
    return { success: false, message: 'মৌজা ম্যাপ আপডেটে ত্রুটি হয়েছে!' };
  }
}

export async function deleteMoujaMap(id: string) {
  try {
    const record = await prisma.moujaMap.findUnique({ where: { id } });
    if (record?.filePath) {
      const filePath = path.join(process.cwd(), 'public', record.filePath);
      unlink(filePath).catch(() => null);
    }
    await prisma.moujaMap.delete({ where: { id } });
    return { success: true, message: 'মৌজা ম্যাপ সফলভাবে মুছা হয়েছে!' };
  } catch (err) {
    console.error(err);
    return { success: false, message: 'মৌজা ম্যাপ মুছতে ত্রুটি হয়েছে!' };
  }
}
