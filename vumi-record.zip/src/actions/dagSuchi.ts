'use server';

import { prisma } from '@/lib/db';
import { writeFile, unlink } from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

const ALLOWED_TYPES = [
  'application/pdf',
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/gif',
];

const MAX_SIZE = 20 * 1024 * 1024; // 20MB

async function saveFile(file: File): Promise<{
  fileName: string;
  originalName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
} | { error: string }> {
  if (file.size > MAX_SIZE) {
    return { error: 'ফাইলের আকার ২০ এমবি এর বেশি হতে পারে না।' };
  }
  if (!ALLOWED_TYPES.includes(file.type)) {
    return { error: 'অনুমতিপ্রাপ্ত ফাইল ধরন: PDF, JPG, PNG, GIF।' };
  }

  const ext = file.name.split('.').pop() || 'bin';
  const fileName = `dag_suchi_${uuidv4()}.${ext}`;
  const uploadDir = path.join(process.cwd(), 'public', 'uploads');
  const bytes = await file.arrayBuffer();
  await writeFile(path.join(uploadDir, fileName), Buffer.from(bytes));

  return {
    fileName,
    originalName: file.name,
    filePath: `/uploads/${fileName}`,
    fileSize: file.size,
    mimeType: file.type,
  };
}

export async function createDagSuchi(formData: FormData) {
  try {
    const moujaId = formData.get('moujaId') as string;
    const file = formData.get('dag_suchi_file_upload') as File | null;

    if (!moujaId) {
      return { success: false, message: 'মৌজা নির্বাচন করুন।' };
    }

    let fileData = { fileName: '', originalName: '', filePath: '', fileSize: 0, mimeType: '' };

    if (file && file.size > 0) {
      const result = await saveFile(file);
      if ('error' in result) return { success: false, message: result.error };
      fileData = result;
    }

    const dagSuchi = await prisma.dagSuchi.create({
      data: { moujaId, ...fileData },
    });

    return { success: true, data: dagSuchi, message: 'দাগ সূচি সফলভাবে সংরক্ষণ হয়েছে!' };
  } catch (err) {
    console.error(err);
    return { success: false, message: 'দাগ সূচি সংরক্ষণে ত্রুটি হয়েছে!' };
  }
}

export async function updateDagSuchi(formData: FormData) {
  try {
    const id = formData.get('id') as string;
    const moujaId = formData.get('moujaId') as string;
    const file = formData.get('dag_suchi_file_upload') as File | null;
    const existingFilePath = formData.get('existingFilePath') as string;

    if (!moujaId) {
      return { success: false, message: 'মৌজা নির্বাচন করুন।' };
    }

    let fileData: Record<string, string | number> = {};

    if (file && file.size > 0) {
      const result = await saveFile(file);
      if ('error' in result) return { success: false, message: result.error };
      fileData = result;

      if (existingFilePath) {
        const oldPath = path.join(process.cwd(), 'public', existingFilePath);
        unlink(oldPath).catch(() => null);
      }
    }

    const dagSuchi = await prisma.dagSuchi.update({
      where: { id },
      data: { moujaId, ...fileData },
    });

    return { success: true, data: dagSuchi, message: 'দাগ সূচি সফলভাবে আপডেট হয়েছে!' };
  } catch (err) {
    console.error(err);
    return { success: false, message: 'দাগ সূচি আপডেটে ত্রুটি হয়েছে!' };
  }
}

export async function deleteDagSuchi(id: string) {
  try {
    const record = await prisma.dagSuchi.findUnique({ where: { id } });
    if (record?.filePath) {
      const oldPath = path.join(process.cwd(), 'public', record.filePath);
      unlink(oldPath).catch(() => null);
    }
    await prisma.dagSuchi.delete({ where: { id } });
    return { success: true, message: 'দাগ সূচি সফলভাবে মুছে ফেলা হয়েছে!' };
  } catch (err) {
    console.error(err);
    return { success: false, message: 'দাগ সূচি মুছতে ত্রুটি হয়েছে!' };
  }
}
