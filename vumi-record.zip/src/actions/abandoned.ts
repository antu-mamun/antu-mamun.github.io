'use server';

import { prisma } from '@/lib/db';

type PersonalInfoItem = {
  name: string;
  parentName: string;
  address: string;
  mobile: string;
};

export async function createAbandoned({
  moujaId,
  caseNo,
  inclusionDate,
  sabakSaKhotianNo,
  sabakSaDagNo,
  halKhotianNo,
  halDagNo,
  dagLandSize,
  category,
  lastRenewalYear,
  originalOwnerInfo,
  lesseeInfo,
  caseInfo,
  governmentPossessionDate,
  reportFilePath,
  reportOriginalName,
  comment,
}: {
  moujaId: string;
  caseNo: string;
  inclusionDate: string;
  sabakSaKhotianNo: string;
  sabakSaDagNo: string;
  halKhotianNo: string;
  halDagNo: string;
  dagLandSize: string;
  category?: string;
  lastRenewalYear?: string;
  originalOwnerInfo?: PersonalInfoItem[];
  lesseeInfo?: PersonalInfoItem[];
  caseInfo?: string;
  governmentPossessionDate?: string;
  reportFilePath?: string;
  reportOriginalName?: string;
  comment?: string;
}) {
  try {
    const abandoned = await prisma.abandoned.create({
      data: {
        moujaId,
        caseNo,
        inclusionDate,
        sabakSaKhotianNo,
        sabakSaDagNo,
        halKhotianNo,
        halDagNo,
        dagLandSize,
        category: category ?? '',
        lastRenewalYear: lastRenewalYear ?? '',
        originalOwnerInfo: JSON.stringify(originalOwnerInfo ?? []),
        lesseeInfo: JSON.stringify(lesseeInfo ?? []),
        caseInfo: caseInfo ?? '',
        governmentPossessionDate: governmentPossessionDate ?? '',
        reportFilePath: reportFilePath ?? '',
        reportOriginalName: reportOriginalName ?? '',
        comment: comment ?? '',
      },
    });
    return {
      success: true,
      data: abandoned,
      message: 'অর্পিত সম্পত্তির তথ্য সফলভাবে সংরক্ষিত হয়েছে!',
    };
  } catch (err) {
    console.log(err);
    return {
      success: false,
      message: 'অর্পিত সম্পত্তির তথ্য সংরক্ষণে ত্রুটি হয়েছে!',
    };
  }
}

export async function updateAbandoned({
  id,
  moujaId,
  caseNo,
  inclusionDate,
  sabakSaKhotianNo,
  sabakSaDagNo,
  halKhotianNo,
  halDagNo,
  dagLandSize,
  category,
  lastRenewalYear,
  originalOwnerInfo,
  lesseeInfo,
  caseInfo,
  governmentPossessionDate,
  reportFilePath,
  reportOriginalName,
  comment,
}: {
  id: string;
  moujaId: string;
  caseNo: string;
  inclusionDate: string;
  sabakSaKhotianNo: string;
  sabakSaDagNo: string;
  halKhotianNo: string;
  halDagNo: string;
  dagLandSize: string;
  category?: string;
  lastRenewalYear?: string;
  originalOwnerInfo?: PersonalInfoItem[];
  lesseeInfo?: PersonalInfoItem[];
  caseInfo?: string;
  governmentPossessionDate?: string;
  reportFilePath?: string;
  reportOriginalName?: string;
  comment?: string;
}) {
  try {
    const abandoned = await prisma.abandoned.update({
      where: { id },
      data: {
        moujaId,
        caseNo,
        inclusionDate,
        sabakSaKhotianNo,
        sabakSaDagNo,
        halKhotianNo,
        halDagNo,
        dagLandSize,
        category: category ?? '',
        lastRenewalYear: lastRenewalYear ?? '',
        originalOwnerInfo: JSON.stringify(originalOwnerInfo ?? []),
        lesseeInfo: JSON.stringify(lesseeInfo ?? []),
        caseInfo: caseInfo ?? '',
        governmentPossessionDate: governmentPossessionDate ?? '',
        reportFilePath: reportFilePath ?? '',
        reportOriginalName: reportOriginalName ?? '',
        comment: comment ?? '',
      },
    });
    return {
      success: true,
      data: abandoned,
      message: 'অর্পিত সম্পত্তির তথ্য সফলভাবে আপডেট হয়েছে!',
    };
  } catch (err) {
    console.error(err);
    return {
      success: false,
      message: 'অর্পিত সম্পত্তির তথ্য আপডেটে ত্রুটি হয়েছে!',
    };
  }
}

export async function deleteAbandoned(id: string) {
  try {
    await prisma.abandoned.delete({ where: { id } });
    return { success: true, message: 'অর্পিত সম্পত্তির তথ্য সফলভাবে মুছে ফেলা হয়েছে!' };
  } catch (err) {
    console.error(err);
    return { success: false, message: 'অর্পিত সম্পত্তির তথ্য মুছতে ত্রুটি হয়েছে!' };
  }
}


// export async function nothiOwner({
//   nothiId,
//   ownerName,
//   gurdianName,
//   address,
// }: {
//   ownerName: string;
//   gurdianName: string;
//   address: string;
//   nothiId: string;
// }) {
//   try {
//     const mouja = await prisma.nothiOwner.create({
//       data: {
//         nothiId,
//         ownerName,
//         gurdianName,
//         address,
//       },
//     });
//     return {
//       success: true,
//       data: mouja,
//       message: 'Nothi owner created successfully!',
//     };
//   } catch (err) {
//     return {
//       success: false,
//       message: 'Error on creating nothi owner!',
//     };
//   }
// }

// export async function createSurvey({
//   saSurvey,
//   saLine,
//   rsLine,
//   rsSurvey,
//   quantiy,
//   type,
//   nothiId,
// }: {
//   saSurvey: string;
//   saLine: string;
//   rsSurvey: string;
//   rsLine: string;
//   quantiy: string;
//   type: string;
//   nothiId: string;
// }) {
//   try {
//     const mouja = await prisma.landSurvey.create({
//       data: {
//         saLine,
//         saSurvey,
//         rsLine,
//         rsSurvey,
//         quantiy,
//         type,
//         nothiId,
//       },
//     });
//     return {
//       success: true,
//       data: mouja,
//       message: 'Nothi survey created successfully!',
//     };
//   } catch (err) {
//     return {
//       success: false,
//       message: 'Error on creating nothi survey!',
//     };
//   }
// }
