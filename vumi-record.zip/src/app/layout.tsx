import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import { Toaster } from '@/components/ui/sonner';
import { validateLicense } from '@/lib/license-check';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'Vumi Record',
  description: 'Vumi Record - A comprehensive record management system',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // ── License enforcement ──────────────────────────────────────────────────
  // This check runs server-side on every request. The app will not serve any
  // content without a valid license.json signed by the project owner.
  if (!validateLicense()) {
    return (
      <html lang="en">
        <body style={{ fontFamily: 'sans-serif', textAlign: 'center', padding: '4rem' }}>
          <h1 style={{ color: '#c0392b' }}>⛔ Application Not Licensed</h1>
          <p>
            A valid <code>license.json</code> signed by the project owner is required
            to run this application.
          </p>
          <p style={{ color: '#666', fontSize: '0.9rem' }}>
            Contact the project owner (Imtiaz Mamun) to obtain a license.
          </p>
        </body>
      </html>
    );
  }
  // ─────────────────────────────────────────────────────────────────────────

  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
        suppressHydrationWarning
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
