import { NextRequest, NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import { cookies } from 'next/headers';
import path from 'path';

export async function GET(request: NextRequest) {
  // Auth check — same pattern as /api/files/[id]
  const cookieStore = await cookies();
  const user = cookieStore.get('user')?.value;
  if (!user) {
    return new NextResponse('Unauthorized', { status: 401 });
  }

  const filePath = request.nextUrl.searchParams.get('path');

  if (!filePath) {
    return new NextResponse('Missing path', { status: 400 });
  }

  // Sanitize: only allow paths under /uploads/ to prevent path traversal
  const normalised = path.normalize(filePath);
  if (!normalised.startsWith('/uploads/')) {
    return new NextResponse('Forbidden', { status: 403 });
  }

  // Strip leading slash and resolve to the public directory
  const absolutePath = path.join(process.cwd(), 'public', normalised);

  try {
    const fileBuffer = await readFile(absolutePath);
    // Slice to a plain ArrayBuffer (BodyInit-compatible)
    const arrayBuffer = fileBuffer.buffer.slice(
      fileBuffer.byteOffset,
      fileBuffer.byteOffset + fileBuffer.byteLength
    ) as ArrayBuffer;

    // Derive content-type from extension
    const ext = path.extname(absolutePath).toLowerCase();
    const contentTypeMap: Record<string, string> = {
      '.pdf': 'application/pdf',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
    };
    const contentType = contentTypeMap[ext] ?? 'application/octet-stream';

    return new NextResponse(arrayBuffer, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        // inline so the browser renders it rather than downloading
        'Content-Disposition': 'inline',
        'Cache-Control': 'private, max-age=3600',
      },
    });
  } catch {
    return new NextResponse('File not found', { status: 404 });
  }
}
