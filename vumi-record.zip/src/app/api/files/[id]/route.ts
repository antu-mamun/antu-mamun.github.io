import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { readFile } from 'fs/promises';
import { getSecureFileData } from '@/actions/files';
import path from 'path';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Check if user is authenticated
    const cookieStore = await cookies();
    const user = cookieStore.get('user')?.value;
    
    if (!user) {
      return new NextResponse('Unauthorized', { status: 401 });
    }

    const { id: fileId } = await params;
    if (!fileId) {
      return new NextResponse('File ID is required', { status: 400 });
    }

    // Get file data securely
    const result = await getSecureFileData(fileId);
    
    if (!result.success || !result.data) {
      return new NextResponse(result.message || 'File not found', { 
        status: 404 
      });
    }

    const fileData = result.data;
    
    // Read the file from the file system
    const filePath = path.join(process.cwd(), 'public', fileData.filePath.replace('/uploads/', 'uploads/'));
    
    try {
      const fileBuffer = await readFile(filePath);
      
      // Get the action from query params (preview or download)
      const url = new URL(request.url);
      const action = url.searchParams.get('action') || 'preview';
      
      // Set appropriate headers
      const headers = new Headers();
      headers.set('Content-Type', fileData.mimeType);
      headers.set('Content-Length', fileData.fileSize.toString());
      
      if (action === 'download') {
        headers.set('Content-Disposition', `attachment; filename="${fileData.originalName}"`);
      } else {
        headers.set('Content-Disposition', `inline; filename="${fileData.originalName}"`);
      }
      
      // Add security headers
      headers.set('X-Content-Type-Options', 'nosniff');
      headers.set('X-Frame-Options', 'SAMEORIGIN');
      headers.set('Cache-Control', 'private, no-cache, no-store, must-revalidate');
      
      return new NextResponse(fileBuffer, {
        status: 200,
        headers,
      });
      
    } catch (fileError) {
      console.error('Error reading file:', fileError);
      return new NextResponse('File not found on disk', { status: 404 });
    }
    
  } catch (error) {
    console.error('Error serving file:', error);
    return new NextResponse('Internal server error', { status: 500 });
  }
}
