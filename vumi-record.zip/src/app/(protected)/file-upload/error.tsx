'use client';

import { useEffect } from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function Error({
    error,
    reset,
}: {
    error: Error & { digest?: string };
    reset: () => void;
}) {
    useEffect(() => {
        console.error('File upload page error:', error);
    }, [error]);

    return (
        <div className="container mx-auto p-6">
            <Card className="max-w-md mx-auto">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-destructive">
                        <AlertTriangle className="h-5 w-5" />
                        কিছু ভুল হয়েছে
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <p className="text-muted-foreground">
                        ফাইল আপলোড পেজ লোড করতে সমস্যা হয়েছে। দয়া করে আবার চেষ্টা করুন।
                    </p>
                    <Button onClick={reset} className="w-full">
                        আবার চেষ্টা করুন
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}
