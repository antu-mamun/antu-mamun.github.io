import FileUploadClient from './FileUploadClient';

export default function FileUploadPage() {
    return <FileUploadClient />;
}
