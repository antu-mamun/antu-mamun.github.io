'use client';

import { useState, useCallback, useEffect } from 'react';
import { FileUploadForm } from '@/components/files/FileUploadForm';
import { FileFilter } from '@/components/files/FileFilter';
import { FileList } from '@/components/files/FileList';
import { Pagination } from '@/components/files/Pagination';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { getFiles, FileUploadType } from '@/actions/files';
import { toast } from 'sonner';
import { Upload, FileText } from 'lucide-react';

export default function FileUploadClient() {
    const [files, setFiles] = useState<FileUploadType[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [pagination, setPagination] = useState({
        page: 1,
        totalPages: 1,
        total: 0,
        limit: 10,
    });
    const [filters, setFilters] = useState({
        search: '',
        startDate: undefined as Date | undefined,
        endDate: undefined as Date | undefined,
    });

    // Single fetchFiles function without dependencies on state
    const fetchFiles = useCallback(async (
        page: number,
        search: string,
        startDate?: Date,
        endDate?: Date,
        limit: number = 10
    ) => {
        setIsLoading(true);
        try {
            const result = await getFiles({
                search: search || '',
                startDate,
                endDate,
                page,
                limit,
            });

            if (result.success && result.data) {
                setFiles(result.data.files);
                setPagination({
                    page: result.data.pagination.page,
                    totalPages: result.data.pagination.totalPages,
                    total: result.data.pagination.total,
                    limit,
                });
            } else {
                console.error('Failed to fetch files:', result.message);
                toast.error(result.message || 'ফাইল তালিকা লোড করতে সমস্যা হয়েছে');
                setFiles([]);
                setPagination({ page: 1, totalPages: 1, total: 0, limit });
            }
        } catch (error) {
            console.error('Error fetching files:', error);
            toast.error('ফাইল তালিকা লোড করতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।');
            setFiles([]);
            setPagination({ page: 1, totalPages: 1, total: 0, limit });
        } finally {
            setIsLoading(false);
        }
    }, []);

    const handleFilterChange = useCallback((newFilters: {
        search: string;
        startDate?: Date;
        endDate?: Date;
    }) => {
        setFilters({
            search: newFilters.search,
            startDate: newFilters.startDate,
            endDate: newFilters.endDate,
        });
        // Immediately fetch with new filters and reset to page 1
        fetchFiles(1, newFilters.search, newFilters.startDate, newFilters.endDate, pagination.limit);
    }, [fetchFiles, pagination.limit]);

    const handlePageChange = useCallback((page: number) => {
        // Fetch with current filters but new page
        fetchFiles(page, filters.search, filters.startDate, filters.endDate, pagination.limit);
    }, [fetchFiles, filters.search, filters.startDate, filters.endDate, pagination.limit]);

    const handleUploadSuccess = useCallback(() => {
        // Refresh the file list and stay on current page if possible
        fetchFiles(1, filters.search, filters.startDate, filters.endDate, pagination.limit);
    }, [fetchFiles, filters.search, filters.startDate, filters.endDate, pagination.limit]);

    const handleFileUpdate = useCallback(() => {
        // Refresh current page with current filters
        fetchFiles(pagination.page, filters.search, filters.startDate, filters.endDate, pagination.limit);
    }, [fetchFiles, pagination.page, filters.search, filters.startDate, filters.endDate, pagination.limit]);

    // Single useEffect for initial load only
    useEffect(() => {
        fetchFiles(1, '', undefined, undefined, 10);
    }, []); // Only runs once on mount

    return (
        <div className="bg-white pb-16 min-h-screen">
            {/* Page Header */}
            <div className="w-full text-center space-y-4 pb-4 sticky top-[1px] z-10 px-8">
                <div className="w-full inline-flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-md">
                    <Upload className="h-6 w-6" />
                    <h1 className="text-xl font-bold">ফাইল আপলোড ও ব্যবস্থাপনা</h1>
                    <p className="text-slate-100 max-w-2xl mx-auto">
                        নতুন ফাইল আপলোড ও ব্যবস্থাপনা করুন।
                    </p>
                </div>
            </div>

            <div className="flex flex-col gap-8 px-8 py-4">
                {/* Upload Form */}
                <FileUploadForm onUploadSuccess={handleUploadSuccess} />

                <Separator />

                {/* Filter Section */}
                <FileFilter
                    onFilterChange={handleFilterChange}
                    isLoading={isLoading}
                />

                {/* File List Section */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <FileText className="h-5 w-5" />
                            ফাইল তালিকা
                            {pagination.total > 0 && (
                                <span className="text-sm font-normal text-muted-foreground">
                                    ({pagination.total}টি ফাইল)
                                </span>
                            )}
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        {isLoading ? (
                            <div className="text-center py-8">
                                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                                <p className="mt-2 text-muted-foreground">ফাইল লোড হচ্ছে...</p>
                            </div>
                        ) : (
                            <FileList
                                files={files}
                                onFileUpdate={handleFileUpdate}
                            />
                        )}
                    </CardContent>
                </Card>

                {/* Pagination */}
                <Pagination
                    currentPage={pagination.page}
                    totalPages={pagination.totalPages}
                    onPageChange={handlePageChange}
                    isLoading={isLoading}
                />
            </div>
        </div>
    );
}
