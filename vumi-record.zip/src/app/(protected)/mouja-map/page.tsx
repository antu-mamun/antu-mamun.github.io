import MoujaMapClient from './MoujaMapClient';
import { prisma } from '@/lib/db';
import { Map } from 'lucide-react';
import { cookies } from 'next/headers';
import AccessDenied from '@/components/common/AccessDenied';

export default async function Page() {
  const cookieStore = await cookies();
  const role = cookieStore.get('user_vumi_role')?.value || '';

  if (role === 'USER') {
    return <AccessDenied />;
  }

  const mouzaData = await prisma.mouja.findMany({
    where: { status: 'ACTIVE' },
    orderBy: { createdAt: 'desc' },
  });

  const mapList = await prisma.moujaMap.findMany({
    include: { mouja: true },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div className="bg-white pb-16 min-h-screen">
      {/* Header */}
      <div className="w-full text-center space-y-4 pb-4 sticky top-[1px] z-10 px-8">
        <div className="w-full inline-flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-md">
          <Map className="h-6 w-6" />
          <h1 className="text-xl font-bold">মৌজা ম্যাপ এন্ট্রি</h1>
          <p className="text-slate-100 max-w-2xl mx-auto">
            মৌজা ম্যাপের তথ্য এন্ট্রি ও সংরক্ষণ করুন।
          </p>
        </div>
      </div>

      <section className="px-8 sm:px-8">
        <div className="w-full">
          <MoujaMapClient mouzaData={mouzaData} mapList={mapList} />
        </div>
      </section>
    </div>
  );
}
