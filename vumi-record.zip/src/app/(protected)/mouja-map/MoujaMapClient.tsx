'use client';

import { useState, useTransition } from 'react';
import MoujaMapForm from '@/components/mouja-map/MoujaMapForm';
import MoujaMapList from '@/components/mouja-map/MoujaMapList';
import { useRouter } from 'next/navigation';
import { ListChecks } from 'lucide-react';

export default function MoujaMapClient({
  mouzaData,
  mapList,
}: {
  mouzaData: any[];
  mapList: any[];
}) {
  const [editData, setEditData] = useState<any | null>(null);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const handleFinishEdit = () => {
    setEditData(null);
    startTransition(() => {
      router.refresh();
    });
  };

  return (
    <div className="mx-auto space-y-8">
      {/* Form Card */}
      <div className="w-full space-y-6">
        <div className="w-full rounded-xl shadow-lg bg-white/80 backdrop-blur-sm p-6">
          <MoujaMapForm
            mouzaData={mouzaData}
            editData={editData}
            onFinishEdit={handleFinishEdit}
            onSuccess={() => startTransition(() => { router.refresh(); })}
          />
        </div>
      </div>

      {/* List Section */}
      <section className="mt-12">
        <div className="flex items-center gap-3 mb-4">
          <ListChecks className="h-6 w-6 text-emerald-600" />
          <h2 className="text-lg md:text-xl font-semibold text-emerald-700">
            মৌজা ম্যাপের তালিকা
          </h2>
        </div>
        <div className="p-4 rounded-xl shadow-lg bg-gradient-to-br from-sky-50 to-sky-100 dark:from-gray-900 dark:to-gray-950 border border-sky-100 dark:border-gray-800">
          <MoujaMapList mapList={mapList} onEdit={setEditData} />
        </div>
      </section>
    </div>
  );
}
