'use client';

import { useState, useTransition } from 'react';
import DagSuchiForm from '@/components/dag-suchi/DagSuchiForm';
import DagSuchiList from '@/components/dag-suchi/DagSuchiList';
import { useRouter } from 'next/navigation';
import { ListChecks } from 'lucide-react';

export default function DagSuchiClient({
  mouzaData,
  suchiList,
}: {
  mouzaData: any[];
  suchiList: any[];
}) {
  const [editData, setEditData] = useState<any | null>(null);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const handleFinishEdit = () => {
    setEditData(null);
    startTransition(() => {
      router.refresh();
    });
  };

  return (
    <div className="mx-auto space-y-8">
      {/* Form Card */}
      <div className="w-full space-y-6">
        <div className="w-full rounded-xl shadow-lg bg-white/80 backdrop-blur-sm p-6">
          <DagSuchiForm
            mouzaData={mouzaData}
            editData={editData}
            onFinishEdit={handleFinishEdit}
            onSuccess={() => startTransition(() => { router.refresh(); })}
          />
        </div>
      </div>

      {/* List Section */}
      <section className="mt-12">
        <div className="flex items-center gap-3 mb-4">
          <ListChecks className="h-6 w-6 text-blue-600" />
          <h2 className="text-lg md:text-xl font-semibold text-blue-700">
            দাগ সূচির তালিকা
          </h2>
        </div>
        <div className="p-4 rounded-xl shadow-lg bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-950 border border-blue-100 dark:border-gray-800">
          <DagSuchiList suchiList={suchiList} onEdit={setEditData} />
        </div>
      </section>
    </div>
  );
}
