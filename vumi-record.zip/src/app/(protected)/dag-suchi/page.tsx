import DagSuchiClient from './DagSuchiClient';
import { prisma } from '@/lib/db';
import { BookOpen } from 'lucide-react';
import { cookies } from 'next/headers';
import AccessDenied from '@/components/common/AccessDenied';

export default async function Page() {
  const cookieStore = await cookies();
  const role = cookieStore.get('user_vumi_role')?.value || '';

  if (role === 'USER') {
    return <AccessDenied />;
  }

  const mouzaData = await prisma.mouja.findMany({
    where: { status: 'ACTIVE' },
    orderBy: { createdAt: 'desc' },
  });

  const suchiList = await prisma.dagSuchi.findMany({
    include: { mouja: true },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div className="bg-white pb-16 min-h-screen">
      {/* Header */}
      <div className="w-full text-center space-y-4 pb-4 sticky top-[1px] z-10 px-8">
        <div className="w-full inline-flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-md">
          <BookOpen className="h-6 w-6" />
          <h1 className="text-xl font-bold">দাগ সূচি এন্ট্রি</h1>
          <p className="text-slate-100 max-w-2xl mx-auto">
            দাগ সূচির তথ্য এন্ট্রি ও সংরক্ষণ করুন।
          </p>
        </div>
      </div>

      <section className="px-8 sm:px-8">
        <div className="w-full">
          <DagSuchiClient mouzaData={mouzaData} suchiList={suchiList} />
        </div>
      </section>
    </div>
  );
}
