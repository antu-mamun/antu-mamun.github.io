import { LoginForm } from '@/components/login-form';
import { Card, CardContent } from '@/components/ui/card';
import { Building2, MapPin, FileText, Shield, Users, Database } from 'lucide-react';
import { DynamicYear } from '@/components/common/DynamicYear';

export default async function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <div className="p-4 bg-blue-600 rounded-full shadow-lg">
              <Building2 className="h-12 w-12 text-white" />
            </div>
          </div>
          <h1 className="text-xl md:text-3xl font-bold text-gray-900 dark:text-white mb-4">
            ভূমি রেকর্ড সিস্টেম
          </h1>
          <p className="text-md md:text-lg text-gray-600 dark:text-gray-300 mb-2">
            Vumi Record Management System
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
            আধুনিক প্রযুক্তির মাধ্যমে ভূমি সংক্রান্ত সকল তথ্য ও নথিপত্র সংরক্ষণ ও ব্যবস্থাপনার জন্য একটি নিরাপদ ও কার্যকর সমাধান
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start max-w-7xl mx-auto">

          {/* Login Section */}
          <div className="flex justify-center">
            <div className="w-full max-w-md">
              <LoginForm />

              {/* Additional Info */}
              <div className="mt-8 text-center">
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-semibold text-blue-900 dark:text-blue-200 mb-2">
                    সিস্টেম তথ্য
                  </h4>
                  <div className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                    <p>• সকল ডেটা এনক্রিপ্টেড ও নিরাপদ</p>
                    <p>• ২৪/৭ সিস্টেম মনিটরিং</p>
                    <p>• নিয়মিত ব্যাকআপ ও আপডেট</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Features Section */}
          <div className="space-y-8">
            <div>
              {/* <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
                সিস্টেমের বৈশিষ্ট্যসমূহ
              </h2> */}

              <div className="grid gap-6 grid-cols-1 sm:grid-cols-2">
                <Card className="border-l-4 border-l-blue-500 shadow-md hover:shadow-lg transition-shadow">
                  <CardContent className="p-2">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                        <MapPin className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                          মৌজা ব্যবস্থাপনা
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          সকল মৌজার তথ্য সংরক্ষণ, সম্পাদনা এবং অনুসন্ধানের সুবিধা
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-green-500 shadow-md hover:shadow-lg transition-shadow">
                  <CardContent className="p-2">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                        <FileText className="h-6 w-6 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                          নথি সংরক্ষণ
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          ভূমি সংক্রান্ত সকল নথিপত্র ডিজিটাল ফরম্যাটে নিরাপদ সংরক্ষণ
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-purple-500 shadow-md hover:shadow-lg transition-shadow">
                  <CardContent className="p-2">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                        <Building2 className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                          পরিত্যক্ত সম্পত্তি
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          অর্পিত সম্পত্তির তালিকা ও বিস্তারিত তথ্য ব্যবস্থাপনা
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-orange-500 shadow-md hover:shadow-lg transition-shadow">
                  <CardContent className="p-2">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-lg">
                        <Shield className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                          নিরাপত্তা ব্যবস্থা
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          উন্নত এনক্রিপশন ও অথেন্টিকেশন সিস্টেমের মাধ্যমে সর্বোচ্চ নিরাপত্তা
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-red-500 shadow-md hover:shadow-lg transition-shadow">
                  <CardContent className="p-2">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-red-100 dark:bg-red-900 rounded-lg">
                        <Users className="h-6 w-6 text-red-600 dark:text-red-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                          ব্যবহারকারী ব্যবস্থাপনা
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          বিভিন্ন স্তরের ব্যবহারকারী ও তাদের অধিকার নিয়ন্ত্রণ
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-l-teal-500 shadow-md hover:shadow-lg transition-shadow">
                  <CardContent className="p-2">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-teal-100 dark:bg-teal-900 rounded-lg">
                        <Database className="h-6 w-6 text-teal-600 dark:text-teal-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                          ডেটা ব্যাকআপ
                        </h3>
                        <p className="text-gray-600 dark:text-gray-300">
                          স্বয়ংক্রিয় ডেটা ব্যাকআপ ও পুনরুদ্ধার ব্যবস্থা
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-16 text-center border-t border-gray-200 dark:border-gray-700 pt-8">
          <p className="text-gray-500 dark:text-gray-400">
            © <DynamicYear /> ভূমি রেকর্ড সিস্টেম। সকল অধিকার সংরক্ষিত।
          </p>
        </div>
      </div>
    </div>
  );
}
