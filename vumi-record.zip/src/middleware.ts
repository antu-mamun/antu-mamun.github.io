import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { isTokenValid } from '@/lib/auth-edge';

const ALLOWED_UPLOAD_DOMAIN = 'www.aclandshibganj.land';

/** Routes that involve file uploads — domain-locked */
const UPLOAD_ROUTES = ['/file-upload', '/mouja-map'];

const IMAGE_EXTENSIONS = [
  '.png',
  '.jpg',
  '.jpeg',
  '.gif',
  '.webp',
  '.svg',
  '.ico',
];

export async function middleware(request: NextRequest) {
  const cookieStore = await cookies();
  const url = request.nextUrl.pathname;
  
  // Block direct access to uploads directory - require authentication
  if (url.startsWith('/uploads/')) {
    return new NextResponse('Forbidden: Direct file access not allowed', { 
      status: 403 
    });
  }

  // ── Upload-route domain enforcement ────────────────────────────────
  // File-upload and mouja-map pages are only accessible from the allowed domain
  if (UPLOAD_ROUTES.some(route => url.startsWith(route))) {
    const host = request.headers.get('host') ?? '';
    const hostname = host.split(':')[0]; // strip port if present
    if (
      hostname !== ALLOWED_UPLOAD_DOMAIN &&
      process.env.NODE_ENV !== 'development'
    ) {
      return new NextResponse('Forbidden: uploads are restricted to www.aclandshibganj.land', {
        status: 403,
      });
    }
  }
  // ───────────────────────────────────────────────────────────────
  
  // Allow static images without authentication
  if (IMAGE_EXTENSIONS.some(ext => url.endsWith(ext))) {
    return NextResponse.next();
  }
  
  // Check authentication for protected routes
  const authToken = cookieStore.get('auth_token')?.value;
  const userCookie = cookieStore.get('user')?.value;
  
  let isAuthenticated = false;
  
  if (authToken) {
    // Use Edge Runtime compatible token validation
    isAuthenticated = isTokenValid(authToken);
    
    // If token is invalid, clear cookies
    if (!isAuthenticated) {
      const response = NextResponse.redirect(new URL('/', request.url));
      response.cookies.delete('auth_token');
      response.cookies.delete('user');
      response.cookies.delete('user_vumi_role');
      return response;
    }
  } else if (userCookie) {
    // Fallback: if only user cookie exists (legacy)
    isAuthenticated = true;
  }
  
  // Redirect to login if not authenticated and trying to access protected routes
  if (!isAuthenticated && url !== '/') {
    return NextResponse.redirect(new URL('/', request.url));
  }
  
  // Redirect to dashboard if authenticated and on login page
  if (isAuthenticated && url === '/') {
    return NextResponse.redirect(new URL('/dashboard', request.url));
  }
  
  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico, sitemap.xml, robots.txt (metadata files)
     */
    '/((?!api|_next/static|_next/image|favicon.ico|sitemap.xml|robots.txt).*)',
  ],
};
