'use server';

import { headers } from 'next/headers';

/**
 * The only domain from which file uploads are permitted.
 * Requests originating from any other domain are rejected.
 */
export const ALLOWED_UPLOAD_DOMAIN = 'www.aclandshibganj.land';

const ALLOWED_ORIGINS = [
  `https://${ALLOWED_UPLOAD_DOMAIN}`,
  `http://${ALLOWED_UPLOAD_DOMAIN}`,
];

/**
 * Call at the top of every server action that writes a file.
 * Returns { allowed: true } if the request comes from the allowed domain,
 * or { allowed: false, message } if it should be blocked.
 */
export async function assertUploadDomain(): Promise<
  { allowed: true } | { allowed: false; message: string }
> {
  const headerStore = await headers();
  const origin = headerStore.get('origin') ?? '';
  const referer = headerStore.get('referer') ?? '';
  const host = headerStore.get('host') ?? '';

  // Primary check: Origin header (set by browsers on all form/fetch submissions)
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    return { allowed: true };
  }

  // Fallback: Referer header (present on page navigations / older browsers)
  if (referer) {
    try {
      const refHost = new URL(referer).hostname;
      if (refHost === ALLOWED_UPLOAD_DOMAIN) return { allowed: true };
    } catch {
      // invalid URL — fall through to deny
    }
  }

  // Last resort: allow when running locally in development
  if (
    process.env.NODE_ENV === 'development' &&
    (host.startsWith('localhost') || host.startsWith('127.0.0.1'))
  ) {
    return { allowed: true };
  }

  console.warn(
    `[UPLOAD BLOCKED] origin="${origin}" referer="${referer}" host="${host}"`
  );

  return {
    allowed: false,
    message: `ফাইল আপলোড শুধুমাত্র ${ALLOWED_UPLOAD_DOMAIN} ডোমেইন থেকে অনুমতিপ্রাপ্ত।`,
  };
}
