import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-key';
const SALT_ROUNDS = parseInt(process.env.BCRYPT_SALT_ROUNDS || '12');

// Password hashing functions
export async function hashPassword(password: string): Promise<string> {
  try {
    const salt = await bcrypt.genSalt(SALT_ROUNDS);
    const hashedPassword = await bcrypt.hash(password, salt);
    return hashedPassword;
  } catch (error) {
    console.error('Error hashing password:', error);
    throw new Error('Failed to hash password');
  }
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  try {
    return await bcrypt.compare(password, hashedPassword);
  } catch (error) {
    console.error('Error verifying password:', error);
    throw new Error('Failed to verify password');
  }
}

// JWT token functions
export function generateToken(payload: { id: string; email: string; role: string }): string {
  try {
    return jwt.sign(payload, JWT_SECRET, { 
      expiresIn: '7d',
      algorithm: 'HS256'
    });
  } catch (error) {
    console.error('Error generating token:', error);
    throw new Error('Failed to generate token');
  }
}

export function verifyToken(token: string): { id: string; email: string; role: string } | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] }) as any;
    return {
      id: decoded.id,
      email: decoded.email,
      role: decoded.role
    };
  } catch (error) {
    console.error('Error verifying token:', error);
    return null;
  }
}

// Environment validation
export function validateEnvVars() {
  const jwtSecret = process.env.JWT_SECRET;
  const defaultSecrets = [
    'your-super-secret-jwt-key-change-this-in-production',
    'fallback-secret-key'
  ];
  
  if (!jwtSecret || defaultSecrets.includes(jwtSecret)) {
    console.warn('⚠️  JWT_SECRET is using default value. Please set a secure secret in production!');
  } else if (jwtSecret.length < 32) {
    console.warn('⚠️  JWT_SECRET is too short. Recommended minimum length is 32 characters.');
  } else {
    console.log('✅ JWT_SECRET is properly configured');
  }
  
  if (!process.env.BCRYPT_SALT_ROUNDS || isNaN(parseInt(process.env.BCRYPT_SALT_ROUNDS))) {
    console.warn('⚠️  BCRYPT_SALT_ROUNDS not properly configured. Using default value of 12.');
  } else {
    console.log('✅ BCRYPT_SALT_ROUNDS is properly configured');
  }
}

// Password validation
export function validatePassword(password: string): { isValid: boolean; message?: string } {
  if (!password) {
    return { isValid: false, message: 'Password is required' };
  }
  
  if (password.length < 6) {
    return { isValid: false, message: 'Password must be at least 6 characters long' };
  }
  
  if (password.length > 100) {
    return { isValid: false, message: 'Password must be less than 100 characters' };
  }
  
  // Check for at least one letter and one number
  const hasLetter = /[a-zA-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  
  if (!hasLetter || !hasNumber) {
    return { isValid: false, message: 'Password must contain at least one letter and one number' };
  }
  
  return { isValid: true };
}
