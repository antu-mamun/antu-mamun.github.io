/**
 * Edge Runtime compatible authentication utilities
 * This file contains auth functions that work in both Edge Runtime and Node.js runtime
 */

// Simple base64 URL-safe encoding/decoding for Edge Runtime
function base64UrlEncode(str: string): string {
  return btoa(str)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

function base64UrlDecode(str: string): string {
  // Add padding if needed
  str += '='.repeat((4 - str.length % 4) % 4);
  // Replace URL-safe characters
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  return atob(str);
}

// Edge Runtime compatible JWT verification (basic)
export function verifyTokenEdge(token: string, secret: string): { id: string; email: string; role: string } | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) {
      return null;
    }

    const [header, payload, signature] = parts;
    
    // Decode payload (we'll skip signature verification in Edge Runtime for now)
    const decodedPayload = base64UrlDecode(payload);
    const parsedPayload = JSON.parse(decodedPayload);
    
    // Check expiration
    if (parsedPayload.exp && Date.now() >= parsedPayload.exp * 1000) {
      return null;
    }
    
    // Return user data
    if (parsedPayload.id && parsedPayload.email && parsedPayload.role) {
      return {
        id: parsedPayload.id,
        email: parsedPayload.email,
        role: parsedPayload.role
      };
    }
    
    return null;
  } catch (error) {
    console.error('Edge token verification error:', error);
    return null;
  }
}

// Simple token validation (checks format and expiration only)
export function isTokenValid(token: string): boolean {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) {
      return false;
    }

    const [, payload] = parts;
    const decodedPayload = base64UrlDecode(payload);
    const parsedPayload = JSON.parse(decodedPayload);
    
    // Check expiration
    if (parsedPayload.exp && Date.now() >= parsedPayload.exp * 1000) {
      return false;
    }
    
    return true;
  } catch (error) {
    return false;
  }
}

// Get user data from token without verification (for basic checks)
export function getTokenPayload(token: string): { id: string; email: string; role: string } | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) {
      return null;
    }

    const [, payload] = parts;
    const decodedPayload = base64UrlDecode(payload);
    const parsedPayload = JSON.parse(decodedPayload);
    
    if (parsedPayload.id && parsedPayload.email && parsedPayload.role) {
      return {
        id: parsedPayload.id,
        email: parsedPayload.email,
        role: parsedPayload.role
      };
    }
    
    return null;
  } catch (error) {
    return null;
  }
}
