# Vumi Record — Post-Install Setup Guide

> Follow these steps after unzipping `vumi-record-<date>.zip`.

---

## 1. Unzip

```bash
unzip vumi-record-<date>.zip -d vumi-record
cd vumi-record
```

---

## 2. Files You Must Create

These files are **intentionally excluded** from the zip. Create them before running anything.

---

### 2a. `.env`  (root of the project)

Used for **local development**.

```
/vumi-record/.env
```

Content:

```env
NODE_ENV=development
DATABASE_URL="file:./prisma/dev.db"
JWT_SECRET="<64-char hex string — see below>"
BCRYPT_SALT_ROUNDS=12
APP_NAME="Vumi Record System"
```

Generate a JWT secret:

```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

---

### 2b. `owner.private.pem`  (root of the project — **dev machine only**)

Your RSA private key used to sign `license.json`.  
**Never place this on a production server.**

```
/vumi-record/owner.private.pem
```

If you don't have this key yet, generate a new keypair:

```bash
node scripts/generate-license-keys.js
```

This outputs both `owner.private.pem` and `owner.public.pem`.

> **IMPORTANT:** `owner.public.pem` is already embedded in the application source.  
> Only regenerate keys if you are setting up a **brand-new** deployment from scratch.

---

### 2c. `license.json`  (root of the project)

The signed runtime license. Generate it with the private key:

```bash
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --note "Local development"
```

With an expiry date (optional):

```bash
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --expires "2027-12-31" \
  --note "Production 2027"
```

Output: `license.json` in the project root.

---

### 2d. `public/uploads/`  (directory — already in zip as empty folder)

The uploads folder is included as an empty directory. No action needed unless you are restoring user-uploaded files from a backup.

---

## 3. Directory Layout After Setup

```
vumi-record/
├── .env                        ← YOU CREATE (step 2a)
├── owner.private.pem           ← YOU CREATE (step 2b, dev only)
├── owner.public.pem            ← YOU CREATE (step 2b, dev only)
├── license.json                ← YOU CREATE (step 2c)
├── .env.example                (reference — already in zip)
├── package.json
├── prisma/
│   └── schema.prisma
├── public/
│   └── uploads/                (empty, already in zip)
├── scripts/
│   ├── generate-license-keys.js
│   └── sign-license.js
├── src/
├── docker/
├── docker-compose.yml
└── Dockerfile
```

---

## 4. Install & Run (Local Development)

```bash
# 1. Install dependencies
npm install

# 2. Generate Prisma client
npx prisma generate

# 3. Create and migrate the database
npx prisma migrate dev --name init

# 4. Start the dev server
npm run dev
```

App runs at: **http://localhost:3000**

---

## 5. First-Time Admin Setup

After the database is created, seed an admin user (if a seed script exists):

```bash
# Check if a seed command exists
npm run | grep seed
```

Otherwise create the first user through the app's registration or directly via Prisma Studio:

```bash
npx prisma studio
```

---

## 6. Production / Docker Deployment

For a full Docker deployment, follow **DEPLOY-DOCKER.md** (included in the zip).

Quick summary:

```
Files to create on the server:
  /opt/vumi/.env.production      ← copy from .env.example, fill in JWT_SECRET
  /opt/vumi/license.json         ← generate on your dev machine, scp to server

Commands on the server:
  docker load < vumi-record.tar.gz
  docker compose up -d
```

See DEPLOY-DOCKER.md §7 – §11 for the full walkthrough.

---

## 7. Checklist

| Step | Done? |
|---|---|
| Unzipped the archive | ☐ |
| Created `.env` | ☐ |
| Generated / placed `owner.private.pem` | ☐ |
| Generated `license.json` | ☐ |
| Ran `npm install` | ☐ |
| Ran `npx prisma generate` | ☐ |
| Ran `npx prisma migrate dev` | ☐ |
| Started app with `npm run dev` | ☐ |
