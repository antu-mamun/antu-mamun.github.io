# Vumi Record — Ubuntu Server Deployment Guide

> **Owner:** Imtiaz Mamun  
> **Project:** Vumi Record System  
> **Stack:** Next.js 15 · Prisma (SQLite) · Node.js 18+  

---

## Table of Contents

1. [Protection System Overview](#1-protection-system-overview)
2. [Prerequisites](#2-prerequisites)
3. [Server Preparation](#3-server-preparation)
4. [Application Deployment (PM2 — Recommended)](#4-application-deployment-pm2--recommended)
5. [Application Deployment (Docker)](#5-application-deployment-docker)
6. [Nginx Reverse Proxy](#6-nginx-reverse-proxy)
7. [SSL with Let's Encrypt](#7-ssl-with-lets-encrypt)
8. [Environment Variables Reference](#8-environment-variables-reference)
9. [License Management](#9-license-management)
10. [Database Migrations](#10-database-migrations)
11. [File Uploads & Persistent Storage](#11-file-uploads--persistent-storage)
12. [Updating the Application](#12-updating-the-application)
13. [Monitoring & Logs](#13-monitoring--logs)
14. [Troubleshooting](#14-troubleshooting)
15. [Security Checklist](#15-security-checklist)

---

## 1. Protection System Overview

This application uses **RSA-2048 cryptographic license enforcement**.

```
Owner (you)                           Server
───────────────────────────────────   ─────────────────────────────────────
owner.private.pem  ──sign──►  license.json  ──► App reads license.json
                                              App verifies signature with
                                              embedded public key in source
                                              ✓ Valid  → App runs normally
                                              ✗ Invalid → App halts, shows error
```

**Key files (NEVER commit to git):**

| File | Where | Purpose |
|---|---|---|
| `owner.private.pem` | Your local machine only | Signs licenses |
| `owner.public.pem` | Your local machine only | For reference (already embedded in source) |
| `license.json` | Server root at runtime | Proves this deployment is authorized |

**Without `license.json` signed with your private key**, the application will refuse to serve any page. Any developer who gets access to the source code cannot run the app without your private key.

---

## 2. Prerequisites

### On your local machine (development)
- Node.js 18+
- `owner.private.pem` (your private key — keep this safe!)

### On the Ubuntu server
- Ubuntu 20.04 LTS or 22.04 LTS (recommended)
- At least 1 GB RAM, 10 GB disk
- A domain name pointing to the server IP (for SSL)

---

## 3. Server Preparation

### 3.1 Connect to your server

```bash
ssh root@YOUR_SERVER_IP
# or
ssh ubuntu@YOUR_SERVER_IP
```

### 3.2 Update system packages

```bash
apt update && apt upgrade -y
```

### 3.3 Install Node.js 18 (via NodeSource)

```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs
node --version   # should print v18.x.x
npm --version
```

### 3.4 Install PM2 (process manager)

```bash
npm install -g pm2
```

### 3.5 Install Nginx

```bash
apt install -y nginx
systemctl enable nginx
systemctl start nginx
```

### 3.6 Create an application user (recommended)

```bash
adduser --system --group --home /var/www/vumi vumi
# All app files will live under /var/www/vumi
```

---

## 4. Application Deployment (PM2 — Recommended)

This method runs the compiled Next.js app directly on Node.js, managed by PM2.

### 4.1 Build locally

Run these commands **on your development machine**:

```bash
# Install dependencies
npm ci

# Build the production bundle
npm run build
```

### 4.2 Generate a production license (on your dev machine)

```bash
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --note "Production — yourdomain.com"
```

This creates `license.json` in the project root.  
> **Do not** pass `--expires` if you want a permanent license.  
> **Do** pass `--expires "2027-01-01"` for time-limited deployments.

### 4.3 Transfer files to the server

Create a deployment archive from the built project:

```bash
# Pack only what the server needs (not node_modules or source)
tar -czf vumi-deploy.tar.gz \
  .next \
  public \
  prisma \
  package.json \
  package-lock.json \
  next.config.ts \
  license.json \
  src/generated

# Copy to server
scp vumi-deploy.tar.gz ubuntu@YOUR_SERVER_IP:/tmp/
```

### 4.4 On the server — extract and set up

```bash
mkdir -p /var/www/vumi
cd /var/www/vumi

tar -xzf /tmp/vumi-deploy.tar.gz

# Install production dependencies only
npm ci --omit=dev

# Set correct ownership
chown -R vumi:vumi /var/www/vumi
```

### 4.5 Create the environment file

```bash
nano /var/www/vumi/.env.production
```

Paste and edit:

```env
NODE_ENV=production
DATABASE_URL="file:/var/www/vumi/data/prod.db"
JWT_SECRET="REPLACE_WITH_A_STRONG_RANDOM_64_CHAR_HEX_STRING"
BCRYPT_SALT_ROUNDS=12
APP_NAME="Vumi Record System"
```

Generate a strong JWT secret:

```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

Secure the file:

```bash
chmod 600 /var/www/vumi/.env.production
chown vumi:vumi /var/www/vumi/.env.production
```

### 4.6 Set up the database directory

```bash
mkdir -p /var/www/vumi/data
chown vumi:vumi /var/www/vumi/data
```

### 4.7 Run Prisma migrations

```bash
cd /var/www/vumi
sudo -u vumi npx prisma migrate deploy
```

### 4.8 Create PM2 ecosystem config

```bash
nano /var/www/vumi/ecosystem.config.js
```

```js
module.exports = {
  apps: [
    {
      name: 'vumi-record',
      script: 'node_modules/.bin/next',
      args: 'start',
      cwd: '/var/www/vumi',
      user: 'vumi',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      env_file: '/var/www/vumi/.env.production',
    },
  ],
};
```

### 4.9 Start the application

```bash
cd /var/www/vumi
pm2 start ecosystem.config.js
pm2 save                         # Save process list so it survives reboots
pm2 startup systemd              # Enable auto-start on system boot
# Follow the command PM2 prints to register the startup service
```

### 4.10 Verify the app is running

```bash
pm2 status
pm2 logs vumi-record --lines 50
curl http://localhost:3000        # Should return HTML, not a license error
```

---

## 5. Application Deployment (Docker)

Use this method if you prefer container-based deployments.

### 5.1 On your dev machine — build the image

```bash
# Generate production license first
node scripts/sign-license.js --owner "Imtiaz Mamun" --project "Vumi Record System"

# Build Docker image
docker build -t vumi-record:latest .
```

### 5.2 Save and transfer image to server

```bash
docker save vumi-record:latest | gzip > vumi-record.tar.gz
scp vumi-record.tar.gz ubuntu@YOUR_SERVER_IP:/tmp/
scp license.json ubuntu@YOUR_SERVER_IP:/tmp/
```

### 5.3 On the server — load image and run

```bash
# Install Docker
apt install -y docker.io
systemctl enable docker
systemctl start docker

# Load image
docker load < /tmp/vumi-record.tar.gz

# Create data directory for SQLite
mkdir -p /var/docker/vumi/data
cp /tmp/license.json /var/docker/vumi/license.json

# Run the container
docker run -d \
  --name vumi-record \
  --restart unless-stopped \
  -p 3000:3000 \
  -v /var/docker/vumi/data:/app/data \
  -v /var/docker/vumi/license.json:/app/license.json:ro \
  -e DATABASE_URL="file:/app/data/prod.db" \
  -e JWT_SECRET="REPLACE_WITH_STRONG_SECRET" \
  -e BCRYPT_SALT_ROUNDS="12" \
  -e NODE_ENV="production" \
  vumi-record:latest
```

### 5.4 Verify Docker container

```bash
docker ps
docker logs vumi-record
curl http://localhost:3000
```

---

## 6. Nginx Reverse Proxy

Nginx sits in front of Next.js, handles SSL termination and serves static assets efficiently.

### 6.1 Create Nginx site config

```bash
nano /etc/nginx/sites-available/vumi-record
```

Paste (replace `yourdomain.com`):

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    # Redirect to HTTPS (uncomment after setting up SSL in step 7)
    # return 301 https://$host$request_uri;

    client_max_body_size 20M;

    location /_next/static/ {
        alias /var/www/vumi/.next/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    location /public/ {
        alias /var/www/vumi/public/;
        expires 7d;
        access_log off;
    }

    location / {
        proxy_pass         http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade $http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
    }
}
```

### 6.2 Enable and test

```bash
ln -s /etc/nginx/sites-available/vumi-record /etc/nginx/sites-enabled/
nginx -t          # Test config — must say "ok"
systemctl reload nginx
```

---

## 7. SSL with Let's Encrypt

```bash
apt install -y certbot python3-certbot-nginx

certbot --nginx -d yourdomain.com -d www.yourdomain.com \
  --non-interactive --agree-tos -m your@email.com

# Auto-renewal is set up automatically; verify:
systemctl status certbot.timer
```

After Certbot runs, it will update your Nginx config with SSL settings automatically.  
Now uncomment the `return 301 https://...` redirect in step 6.1 and reload Nginx:

```bash
nginx -t && systemctl reload nginx
```

---

## 8. Environment Variables Reference

| Variable | Required | Description |
|---|---|---|
| `DATABASE_URL` | ✓ | Path to SQLite DB — e.g. `file:/var/www/vumi/data/prod.db` |
| `JWT_SECRET` | ✓ | 64-character hex string for JWT signing. Generate with: `node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"` |
| `BCRYPT_SALT_ROUNDS` | — | Default `12`. Higher = more secure but slower. |
| `APP_NAME` | — | Display name. Default: `Vumi Record System` |
| `NODE_ENV` | ✓ | Must be `production` on server |
| `PORT` | — | Default `3000` |

---

## 9. License Management

### 9.1 Generate a new license for a deployment (run on your dev machine)

```bash
# No expiry (permanent)
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --note "Production server — yourdomain.com"

# With expiry (renew yearly)
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --expires "2027-12-31" \
  --note "Annual license — yourdomain.com"
```

This writes `license.json` in the project root.

### 9.2 Transfer license to server

```bash
scp license.json ubuntu@YOUR_SERVER_IP:/var/www/vumi/license.json
chown vumi:vumi /var/www/vumi/license.json
chmod 644 /var/www/vumi/license.json
```

**Restart the app** after transferring a new license:

```bash
pm2 restart vumi-record
# or for Docker:
docker restart vumi-record
```

### 9.3 Revoking a deployment

Simply delete or replace `license.json` on the server to immediately disable access:

```bash
rm /var/www/vumi/license.json
pm2 restart vumi-record
```

The app will immediately show the "Application Not Licensed" error to all users.

### 9.4 Key rotation (if private key is ever compromised)

1. On your dev machine, generate a new key pair:
   ```bash
   node scripts/generate-license-keys.js
   ```
2. Open `src/lib/license-check.ts` and replace the `OWNER_PUBLIC_KEY` constant with the contents of the new `owner.public.pem`.
3. Rebuild and redeploy the application.
4. Generate a new `license.json` with the new private key and transfer to server.
5. Securely delete the old `owner.private.pem`.

---

## 10. Database Migrations

### First deployment

```bash
cd /var/www/vumi
sudo -u vumi npx prisma migrate deploy
```

### On every update (if schema changed)

```bash
cd /var/www/vumi
sudo -u vumi npx prisma migrate deploy
pm2 restart vumi-record
```

### Backup the SQLite database

```bash
# Simple copy backup
cp /var/www/vumi/data/prod.db /var/backups/vumi/prod-$(date +%Y%m%d-%H%M%S).db

# Scheduled backup with cron (daily at 2am)
crontab -e
# Add:
# 0 2 * * * cp /var/www/vumi/data/prod.db /var/backups/vumi/prod-$(date +\%Y\%m\%d).db
```

---

## 11. File Uploads & Persistent Storage

Uploaded files are stored in `public/uploads/`. This directory must persist across deployments.

### For PM2 deployment

```bash
mkdir -p /var/www/vumi/public/uploads
chown -R vumi:vumi /var/www/vumi/public/uploads
```

When updating, do **not** delete the `public/uploads/` directory.

### For Docker deployment

Mount as a volume:

```bash
-v /var/docker/vumi/uploads:/app/public/uploads
```

---

## 12. Updating the Application

### PM2 deployment

On your **dev machine**:

```bash
# 1. Make code changes, then build
npm ci && npm run build

# 2. Generate a new license if needed
node scripts/sign-license.js --owner "Imtiaz Mamun" --project "Vumi Record System"

# 3. Pack the update
tar -czf vumi-update.tar.gz \
  .next \
  public \
  prisma \
  package.json \
  package-lock.json \
  next.config.ts \
  license.json \
  src/generated

scp vumi-update.tar.gz ubuntu@YOUR_SERVER_IP:/tmp/
```

On the **server**:

```bash
cd /var/www/vumi

# Backup DB
cp data/prod.db /var/backups/vumi/pre-update-$(date +%Y%m%d).db

# Extract update (preserves .env.production and data/)
tar -xzf /tmp/vumi-update.tar.gz
npm ci --omit=dev

# Run migrations if schema changed
sudo -u vumi npx prisma migrate deploy

# Restart with zero downtime
pm2 reload vumi-record
```

### Docker deployment

```bash
# On dev machine
docker build -t vumi-record:latest .
docker save vumi-record:latest | gzip > vumi-record-new.tar.gz
scp vumi-record-new.tar.gz ubuntu@YOUR_SERVER_IP:/tmp/

# On server
docker load < /tmp/vumi-record-new.tar.gz
docker stop vumi-record
docker rm vumi-record
docker run -d --name vumi-record ... # same run command as before
```

---

## 13. Monitoring & Logs

### PM2 commands

```bash
pm2 status                      # Process status
pm2 logs vumi-record            # Live logs
pm2 logs vumi-record --lines 100 # Last 100 log lines
pm2 monit                       # CPU/RAM dashboard
```

### Nginx logs

```bash
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### Docker logs

```bash
docker logs -f vumi-record
docker logs vumi-record --tail 100
```

---

## 14. Troubleshooting

### App shows "Application Not Licensed"

1. Check `license.json` exists in the app root: `ls -la /var/www/vumi/license.json`
2. Verify the signature is valid — check server logs: `pm2 logs vumi-record`
3. Check if the license has expired: `cat /var/www/vumi/license.json | node -e "const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); console.log(d.payload)"`
4. Regenerate and re-transfer `license.json` (see [section 9.2](#92-transfer-license-to-server))

### App won't start — port already in use

```bash
lsof -i :3000
kill -9 <PID>
pm2 restart vumi-record
```

### Prisma database errors

```bash
cd /var/www/vumi
sudo -u vumi npx prisma migrate deploy
sudo -u vumi npx prisma db push      # Emergency: apply schema without migrations
```

### Nginx 502 Bad Gateway

```bash
pm2 status            # Is the app running?
curl http://localhost:3000  # Can Nginx reach the app?
pm2 restart vumi-record
```

### Permission errors on uploads

```bash
chown -R vumi:vumi /var/www/vumi/public/uploads
chmod -R 755 /var/www/vumi/public/uploads
```

---

## 15. Security Checklist

- [ ] `owner.private.pem` is stored securely on your local machine only — **never on the server, never in git**
- [ ] `license.json` is **not** committed to git (`.gitignore` enforces this)
- [ ] `JWT_SECRET` is a unique, long random string — not reused from dev
- [ ] `.env.production` has `chmod 600` permissions
- [ ] UFW firewall is configured — only ports 22, 80, 443 open:
  ```bash
  ufw allow OpenSSH
  ufw allow 'Nginx Full'
  ufw enable
  ```
- [ ] SSH key authentication only (no password SSH):
  ```bash
  # In /etc/ssh/sshd_config:
  PasswordAuthentication no
  ```
- [ ] Certbot SSL certificate auto-renewal is active (`systemctl status certbot.timer`)
- [ ] Database is backed up regularly
- [ ] The application runs as the unprivileged `vumi` user, not as root

---

## Quick Reference — Initial Deployment Checklist

```
Local (dev machine):
  □ npm ci && npm run build
  □ node scripts/sign-license.js --owner "Imtiaz Mamun" --project "Vumi Record System"
  □ tar up build artifacts + license.json
  □ scp to server

Server:
  □ apt update && apt upgrade
  □ Install Node.js 18, PM2, Nginx
  □ Create /var/www/vumi, set up user
  □ Extract app files, npm ci --omit=dev
  □ Create .env.production with DATABASE_URL + JWT_SECRET
  □ mkdir -p data && prisma migrate deploy
  □ pm2 start ecosystem.config.js && pm2 save && pm2 startup
  □ Configure Nginx reverse proxy
  □ certbot --nginx (SSL)
  □ ufw enable (firewall)
  □ Test: curl https://yourdomain.com
```

---

*This document covers the complete deployment lifecycle for the Vumi Record System. The license enforcement system ensures only you (Imtiaz Mamun) can authorize running instances of this application.*
