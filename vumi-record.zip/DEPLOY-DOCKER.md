# Vumi Record — Docker Deployment Guide

> **Owner:** Imtiaz Mamun  
> **Project:** Vumi Record System  
> **Stack:** Next.js 15 · Prisma (SQLite) · Nginx · Certbot  
> **Deployment method:** Docker Compose  

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Protection System — How Licensing Works with Docker](#2-protection-system--how-licensing-works-with-docker)
3. [Prerequisites](#3-prerequisites)
4. [Server Setup (Ubuntu 20.04 / 22.04)](#4-server-setup-ubuntu-2004--2204)
5. [Prepare the Application (on your dev machine)](#5-prepare-the-application-on-your-dev-machine)
6. [Transfer Files to Server](#6-transfer-files-to-server)
7. [Server-Side Configuration](#7-server-side-configuration)
8. [Domain Configuration](#8-domain-configuration)
9. [First Deployment (HTTP)](#9-first-deployment-http)
10. [SSL with Let's Encrypt](#10-ssl-with-lets-encrypt)
11. [Switch to Full HTTPS](#11-switch-to-full-https)
12. [License Management with Docker](#12-license-management-with-docker)
13. [Updating the Application](#13-updating-the-application)
14. [Persistent Data & Backups](#14-persistent-data--backups)
15. [Monitoring & Logs](#15-monitoring--logs)
16. [Troubleshooting](#16-troubleshooting)
17. [Security Checklist](#17-security-checklist)
18. [Quick-Start Checklist](#18-quick-start-checklist)

---

## 1. Architecture Overview

```
Internet
   │
   ▼  :80 / :443
┌──────────────────────────────────────────────────┐
│  Docker Compose Stack (vumi-net)                  │
│                                                   │
│  ┌─────────────────────┐                          │
│  │  nginx:1.27-alpine  │  ← SSL termination,      │
│  │  (vumi-nginx)       │    static asset cache,   │
│  └──────────┬──────────┘    security headers      │
│             │ :3000 (internal)                    │
│  ┌──────────▼──────────┐                          │
│  │  vumi-record:latest │  ← Next.js 15 app         │
│  │  (vumi-app)         │    Prisma migrations      │
│  └──────────────────────┘    license validation    │
│                                                   │
│  ┌──────────────────────┐                          │
│  │  certbot/certbot     │  ← Auto-renews SSL cert  │
│  │  (vumi-certbot)      │                          │
│  └──────────────────────┘                          │
│                                                   │
│  Named volumes:                                   │
│   vumi-db        → /app/data         (SQLite DB)  │
│   vumi-uploads   → /app/public/uploads            │
│   vumi-certbot-* → /etc/letsencrypt               │
└──────────────────────────────────────────────────┘
```

---

## 2. Protection System — How Licensing Works with Docker

The `license.json` file is **never baked into the Docker image**. It is mounted at runtime from the host:

```yaml
volumes:
  - ./license.json:/app/license.json:ro   # read-only inside container
```

**Consequence:** If `license.json` is missing or tampered with on the host, the container serves the "Application Not Licensed" error to every request. The image itself is useless without a license you signed.

```
Your machine               Host server              Docker container
─────────────────          ──────────────────       ────────────────────────
owner.private.pem          license.json             /app/license.json (ro)
       │                   (from your machine)              │
       └── sign ──────────────────────────────────────────► validates against
                                                            embedded public key
```

To revoke a deployment instantly:

```bash
rm /opt/vumi/license.json
docker compose restart app
```

---

## 3. Prerequisites

### On your development machine
- Docker Desktop or Docker Engine 24+
- `docker compose` v2 (`docker compose version`)
- `owner.private.pem` (your RSA private key — never leave your machine)
- Node.js 18+ (to run signing scripts)

### On the Ubuntu server
- Ubuntu 20.04 LTS or 22.04 LTS
- At least **1 GB RAM**, **20 GB disk**
- A **domain name** with an A record pointing to the server IP
- SSH access

---

## 4. Server Setup (Ubuntu 20.04 / 22.04)

### 4.1 Connect and update

```bash
ssh ubuntu@YOUR_SERVER_IP
sudo apt update && sudo apt upgrade -y
```

### 4.2 Install Docker Engine

```bash
# Install prerequisites
sudo apt install -y ca-certificates curl gnupg

# Add Docker's official GPG key
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Add repository
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Verify
docker --version
docker compose version
```

### 4.3 Allow your user to run Docker (no sudo)

```bash
sudo usermod -aG docker $USER
newgrp docker          # apply without logout
```

### 4.4 Create application directory

```bash
sudo mkdir -p /opt/vumi
sudo chown $USER:$USER /opt/vumi
```

### 4.5 Configure UFW firewall

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable
sudo ufw status
```

---

## 5. Prepare the Application (on your dev machine)

### 5.1 Edit domain in Nginx configs

Open `docker/nginx/conf.d/vumi.conf` and replace every instance of `yourdomain.com`:

```bash
# Example with sed:
sed -i 's/yourdomain.com/your-actual-domain.com/g' docker/nginx/conf.d/vumi.conf
sed -i 's/yourdomain.com/your-actual-domain.com/g' docker/nginx/conf.d/vumi-ssl.conf
```

### 5.2 Generate a production license

```bash
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --note "Docker production — your-actual-domain.com"
```

Output: `license.json` in the project root.

### 5.3 Build the Docker image

```bash
docker build -t vumi-record:latest .
```

### 5.4 Export the image

```bash
docker save vumi-record:latest | gzip > vumi-record.tar.gz
```

---

## 6. Transfer Files to Server

```bash
# Transfer the Docker image
scp vumi-record.tar.gz ubuntu@YOUR_SERVER_IP:/opt/vumi/

# Transfer the compose stack and configs
scp docker-compose.yml                  ubuntu@YOUR_SERVER_IP:/opt/vumi/
scp .env.example                        ubuntu@YOUR_SERVER_IP:/opt/vumi/
scp license.json                        ubuntu@YOUR_SERVER_IP:/opt/vumi/
scp -r docker/                          ubuntu@YOUR_SERVER_IP:/opt/vumi/
```

---

## 7. Server-Side Configuration

### 7.1 Load the Docker image

```bash
cd /opt/vumi
docker load < vumi-record.tar.gz
docker images | grep vumi-record    # verify image is loaded
```

### 7.2 Create the environment file

```bash
cp .env.example .env.production
nano .env.production
```

Fill in:

```env
NODE_ENV=production
DATABASE_URL="file:/app/data/prod.db"
JWT_SECRET="PASTE_YOUR_64_CHAR_HEX_SECRET_HERE"
BCRYPT_SALT_ROUNDS=12
APP_NAME="Vumi Record System"
```

Generate a strong JWT secret if you haven't:

```bash
docker run --rm node:18-alpine node \
  -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

Secure the file:

```bash
chmod 600 /opt/vumi/.env.production
```

### 7.3 Verify license.json is present

```bash
ls -la /opt/vumi/license.json
# Must exist — the app container will not serve anything without it
```

---

## 8. Domain Configuration

### 8.1 Point your domain to the server

In your DNS provider (Cloudflare, Namecheap, Route53, etc.), create:

| Type | Name | Value | TTL |
|---|---|---|---|
| A | `yourdomain.com` | `YOUR_SERVER_IP` | 300 |
| A | `www` | `YOUR_SERVER_IP` | 300 |

> DNS propagation can take up to 30 minutes. Check with:  
> `dig +short yourdomain.com`

### 8.2 Verify domain resolves to your server before continuing

```bash
curl -I http://yourdomain.com    # should reach your server (may get Nginx 404 initially)
```

---

## 9. First Deployment (HTTP)

We start with HTTP only so that Certbot can verify domain ownership.

### 9.1 Ensure vumi.conf (HTTP-only) is active

```bash
ls /opt/vumi/docker/nginx/conf.d/
# vumi.conf should be present (HTTP only)
# vumi-ssl.conf should NOT be active yet (rename or delete if present)
```

If both files are in `conf.d/`, Nginx will load both. Temporarily rename the SSL one:

```bash
mv /opt/vumi/docker/nginx/conf.d/vumi-ssl.conf \
   /opt/vumi/docker/nginx/conf.d/vumi-ssl.conf.disabled
```

### 9.2 Start the stack

```bash
cd /opt/vumi
docker compose up -d
```

### 9.3 Verify all containers are running

```bash
docker compose ps
# Expected:
#   vumi-app      running   (healthy)
#   vumi-nginx    running
#   vumi-certbot  running
```

### 9.4 Check app is responding

```bash
curl -s http://localhost         | head -5     # via Nginx
curl -s http://yourdomain.com    | head -5     # via domain
```

You should see HTML. If you see "Application Not Licensed", check [section 12](#12-license-management-with-docker).

---

## 10. SSL with Let's Encrypt

### 10.1 Issue the certificate

```bash
docker compose run --rm certbot \
  certbot certonly \
  --webroot \
  --webroot-path /var/www/certbot \
  -d www.aclandshibganj.land \
  -d aclandshibganj.land \
  --email your@email.com \
  --agree-tos \
  --no-eff-email
```

> Replace `yourdomain.com` and `your@email.com`.

### 10.2 Verify certificate was issued

```bash
docker compose run --rm certbot certbot certificates
# Should list your domain with expiry date
```

---

## 11. Switch to Full HTTPS

### 11.1 Swap Nginx configs

```bash
cd /opt/vumi/docker/nginx/conf.d

# Disable the HTTP-only config
mv vumi.conf vumi.conf.bak

# Enable the SSL config
mv vumi-ssl.conf.disabled vumi-ssl.conf
# (If you didn't rename it in step 9.1, it's already vumi-ssl.conf)
```

### 11.2 Verify the SSL cert paths match in vumi-ssl.conf

Open `vumi-ssl.conf` and confirm the certificate paths use your actual domain:

```nginx
ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
```

### 11.3 Reload Nginx

```bash
docker compose exec nginx nginx -t            # test config
docker compose exec nginx nginx -s reload     # reload without downtime
```

### 11.4 Test HTTPS

```bash
curl -I https://yourdomain.com
# HTTP/2 200 — and Strict-Transport-Security header present
```

### 11.5 Auto-renewal

The `certbot` service in `docker-compose.yml` runs `certbot renew` every 12 hours automatically. Verify it's running:

```bash
docker compose ps certbot
docker compose logs certbot
```

---

## 12. License Management with Docker

### 12.1 Generate a license (on your dev machine)

```bash
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --note "Docker production — yourdomain.com"

# With annual expiry (optional):
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --expires "2027-12-31" \
  --note "Annual license 2027 — yourdomain.com"
```

### 12.2 Transfer and activate new license

```bash
# Transfer to server
scp license.json ubuntu@YOUR_SERVER_IP:/opt/vumi/license.json

# Restart the app container to pick up the new license
# (No rebuild needed — license is mounted at runtime)
cd /opt/vumi
docker compose restart app
```

### 12.3 Verify license is accepted

```bash
docker compose logs app | grep "\[LICENSE\]"
# Expected: [LICENSE] Valid license. Owner: Imtiaz Mamun, Project: Vumi Record System
```

### 12.4 Revoke a deployment immediately

```bash
cd /opt/vumi
rm license.json                    # remove the license
docker compose restart app         # app now shows "Not Licensed" to all users
```

### 12.5 Issue a time-limited license for a contractor

```bash
# On your dev machine — expires in 7 days
node scripts/sign-license.js \
  --owner "Imtiaz Mamun" \
  --project "Vumi Record System" \
  --expires "$(node -e "const d=new Date(); d.setDate(d.getDate()+7); console.log(d.toISOString().slice(0,10))")" \
  --note "Contractor temp license"
```

Transfer `license.json` to the contractor's server. It will automatically stop working after 7 days.

---

## 13. Updating the Application

### 13.1 Build the updated image (on your dev machine)

```bash
# Pull latest code, build, export
npm ci && npm run build              # optional local test
docker build -t vumi-record:latest .
docker save vumi-record:latest | gzip > vumi-record.tar.gz

# Transfer to server
scp vumi-record.tar.gz ubuntu@YOUR_SERVER_IP:/opt/vumi/
```

### 13.2 Apply update on server (zero-downtime)

```bash
cd /opt/vumi

# Backup database before update
docker run --rm \
  -v vumi_vumi-db:/data \
  -v $(pwd)/backups:/backup \
  alpine sh -c "cp /data/prod.db /backup/pre-update-$(date +%Y%m%d-%H%M%S).db"

# Load new image
docker load < vumi-record.tar.gz

# Recreate only the app container (Nginx stays up — no downtime for static requests)
docker compose up -d --no-deps app

# Watch logs to confirm clean start
docker compose logs -f app --tail 50
```

### 13.3 Roll back if needed

```bash
# Tag the old image before updating (optional but recommended)
docker tag vumi-record:latest vumi-record:previous

# Roll back
docker compose stop app
docker tag vumi-record:previous vumi-record:latest
docker compose up -d --no-deps app
```

---

## 14. Persistent Data & Backups

### Named volumes

| Volume | Container path | Contents |
|---|---|---|
| `vumi-db` | `/app/data` | SQLite database (`prod.db`) |
| `vumi-uploads` | `/app/public/uploads` | User-uploaded files |
| `vumi-certbot-conf` | `/etc/letsencrypt` | SSL certificates |
| `vumi-certbot-www` | `/var/www/certbot` | ACME challenge files |

### Manual database backup

```bash
mkdir -p /opt/vumi/backups

docker run --rm \
  -v vumi_vumi-db:/data \
  -v /opt/vumi/backups:/backup \
  alpine \
  cp /data/prod.db /backup/prod-$(date +%Y%m%d-%H%M%S).db

ls -lh /opt/vumi/backups/
```

> **Note:** Docker Compose prefixes volume names with the compose project name (directory name). If your directory is `/opt/vumi`, volumes are named `vumi_vumi-db`, `vumi_vumi-uploads`, etc. Verify with `docker volume ls`.

### Scheduled backup (cron)

```bash
crontab -e
# Add — daily at 2:30am:
30 2 * * * docker run --rm -v vumi_vumi-db:/data -v /opt/vumi/backups:/backup alpine cp /data/prod.db /backup/prod-$(date +\%Y\%m\%d).db
```

### Restore database from backup

```bash
docker compose stop app

docker run --rm \
  -v vumi_vumi-db:/data \
  -v /opt/vumi/backups:/backup \
  alpine \
  cp /backup/prod-20260621.db /data/prod.db

docker compose start app
```

---

## 15. Monitoring & Logs

### Live logs

```bash
docker compose logs -f              # all services
docker compose logs -f app          # app only
docker compose logs -f nginx        # nginx only
docker compose logs -f certbot      # certbot only
```

### Container stats (CPU / RAM)

```bash
docker stats vumi-app vumi-nginx
```

### Container status

```bash
docker compose ps
```

### Nginx access/error logs

```bash
docker compose exec nginx tail -f /var/log/nginx/access.log
docker compose exec nginx tail -f /var/log/nginx/error.log
```

### Health check status

```bash
docker inspect --format='{{.State.Health.Status}}' vumi-app
```

---

## 16. Troubleshooting

### App shows "Application Not Licensed"

```bash
# Check license exists on host
ls -la /opt/vumi/license.json

# Check it's mounted inside container
docker compose exec app ls -la /app/license.json

# Check license validation output
docker compose logs app | grep "\[LICENSE\]"
```

Re-generate and transfer `license.json` if missing (see [section 12.2](#122-transfer-and-activate-new-license)).

---

### Container won't start

```bash
docker compose logs app --tail 100
docker compose ps
```

Common cause: missing `.env.production` or invalid `DATABASE_URL`.

---

### Nginx shows 502 Bad Gateway

```bash
# Is the app container healthy?
docker compose ps app

# Can Nginx reach the app internally?
docker compose exec nginx wget -qO- http://app:3000 | head -5

# Restart app
docker compose restart app
```

---

### SSL certificate not found (Nginx fails to start after switching to SSL config)

```bash
# Verify certificate exists inside certbot volume
docker compose run --rm certbot certbot certificates

# If not found, re-issue (ensure DNS points to server first)
docker compose run --rm certbot certbot certonly \
  --webroot --webroot-path /var/www/certbot \
  -d yourdomain.com -d www.yourdomain.com \
  --email your@email.com --agree-tos --no-eff-email
```

---

### Prisma migration errors

```bash
# Run migrations manually inside a temporary container
docker compose run --rm \
  --env-file .env.production \
  app \
  sh -c "npx prisma migrate deploy"
```

---

### Port 80/443 already in use

```bash
sudo lsof -i :80
sudo lsof -i :443
# Kill the conflicting process, then:
docker compose up -d
```

If Apache or another Nginx is running on the host:

```bash
sudo systemctl stop apache2 nginx
sudo systemctl disable apache2 nginx
```

---

## 17. Security Checklist

- [ ] `owner.private.pem` — only on your local machine, **never on the server**
- [ ] `license.json` — not committed to git (`.gitignore` enforces this)
- [ ] `.env.production` has `chmod 600` and contains a unique `JWT_SECRET`
- [ ] UFW firewall allows only ports 22, 80, 443
- [ ] SSH password authentication is disabled:
  ```bash
  # /etc/ssh/sshd_config → PasswordAuthentication no
  sudo systemctl restart sshd
  ```
- [ ] Docker socket is not exposed publicly
- [ ] SSL certificate auto-renewal is working (`docker compose logs certbot`)
- [ ] Database backups are running on cron
- [ ] The app container runs as non-root user `nextjs` (uid 1001)

---

## 18. Quick-Start Checklist

```
On your dev machine:
  □ Edit docker/nginx/conf.d/vumi.conf       → replace yourdomain.com
  □ Edit docker/nginx/conf.d/vumi-ssl.conf   → replace yourdomain.com
  □ node scripts/sign-license.js --owner "Imtiaz Mamun" --project "Vumi Record System"
  □ docker build -t vumi-record:latest .
  □ docker save vumi-record:latest | gzip > vumi-record.tar.gz
  □ scp vumi-record.tar.gz, docker-compose.yml, docker/, .env.example,
        license.json → /opt/vumi/ on server

On the server:
  □ Install Docker Engine + docker compose plugin
  □ ufw allow OpenSSH / 80 / 443 → ufw enable
  □ cd /opt/vumi && docker load < vumi-record.tar.gz
  □ cp .env.example .env.production → fill in JWT_SECRET + DATABASE_URL
  □ chmod 600 .env.production
  □ Disable vumi-ssl.conf (rename to .disabled)
  □ docker compose up -d
  □ Verify: curl http://yourdomain.com → should show app HTML

  SSL (once domain resolves):
  □ docker compose run --rm certbot certbot certonly \
        --webroot --webroot-path /var/www/certbot \
        -d yourdomain.com -d www.yourdomain.com \
        --email your@email.com --agree-tos --no-eff-email
  □ mv vumi.conf vumi.conf.bak && mv vumi-ssl.conf.disabled vumi-ssl.conf
  □ docker compose exec nginx nginx -t
  □ docker compose exec nginx nginx -s reload
  □ Verify: curl -I https://yourdomain.com → HTTP/2 200
```

---

*The Docker license mount (`-v ./license.json:/app/license.json:ro`) means the image is cryptographically inert without your signed license. You can distribute the image freely — it cannot be used without your authorization.*
