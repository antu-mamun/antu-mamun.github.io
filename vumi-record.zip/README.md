# vumi-record

# db push

npx prisma db push

# run db server

npx prisma studio
