#!/usr/bin/env node

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

/**
 * Generate a secure JWT secret and update .env file
 */
function updateJWTSecret() {
  try {
    console.log('🔑 Generating secure JWT secret...\n');

    // Generate a secure 64-byte secret
    const secret = crypto.randomBytes(64).toString('hex');

    // Path to .env file
    const envPath = path.join(process.cwd(), '.env');

    // Read current .env file
    let envContent;
    try {
      envContent = fs.readFileSync(envPath, 'utf8');
    } catch (error) {
      console.error('❌ Could not read .env file:', error.message);
      return;
    }

    // Replace the JWT_SECRET line
    const updatedContent = envContent.replace(
      /JWT_SECRET=".*"/,
      `JWT_SECRET="${secret}"`,
    );

    // Write back to .env
    fs.writeFileSync(envPath, updatedContent);

    console.log('✅ JWT_SECRET updated successfully!');
    console.log(`📝 Secret length: ${secret.length} characters`);
    console.log(`🔒 Secret preview: ${secret.substring(0, 16)}...`);
    console.log(
      '\n🚀 Please restart your development server for changes to take effect',
    );
    console.log('⚠️  All existing user sessions will be invalidated\n');
  } catch (error) {
    console.error('❌ Error updating JWT_SECRET:', error.message);
  }
}

// Run the function
updateJWTSecret();
