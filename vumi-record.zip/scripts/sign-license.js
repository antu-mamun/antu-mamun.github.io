#!/usr/bin/env node
/**
 * sign-license.js
 * ───────────────
 * Run this script (as the project owner) to generate a valid license.json
 * for a deployment. You MUST have owner.private.pem (your private key).
 *
 * Usage:
 *   node scripts/sign-license.js
 *
 * Or with custom options:
 *   node scripts/sign-license.js --owner "Imtiaz Mamun" --expires "2027-01-01"
 *
 * Outputs: license.json in the project root.
 * Copy license.json to the server before starting the app.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// ─── Parse simple CLI args ──────────────────────────────────────────────────
const args = process.argv.slice(2);
function getArg(name, defaultVal) {
  const idx = args.indexOf(`--${name}`);
  return idx !== -1 ? args[idx + 1] : defaultVal;
}

const owner      = getArg('owner',   'Imtiaz Mamun');
const project    = getArg('project', 'Vumi Record System');
const expiresArg = getArg('expires', null);   // e.g. "2027-12-31" or omit for no-expiry
const note       = getArg('note',    'Production license');

// ─── Load private key ───────────────────────────────────────────────────────
const privateKeyPath = path.join(__dirname, '..', 'owner.private.pem');
if (!fs.existsSync(privateKeyPath)) {
  console.error(
    '\n[ERROR] owner.private.pem not found.\n' +
    '  Place the private key file at the project root, then re-run this script.\n'
  );
  process.exit(1);
}

const privateKey = fs.readFileSync(privateKeyPath, 'utf-8');

// ─── Build payload ──────────────────────────────────────────────────────────
const payload = {
  owner,
  project,
  issuedAt:  new Date().toISOString(),
  expiresAt: expiresArg ? new Date(expiresArg).toISOString() : null,
  note,
};

// ─── Sign payload ────────────────────────────────────────────────────────────
const sign = crypto.createSign('SHA256');
sign.update(JSON.stringify(payload));
sign.end();

const signature = sign.sign(privateKey, 'base64');

// ─── Write license.json ──────────────────────────────────────────────────────
const licenseFile = { payload, signature };
const outputPath  = path.join(__dirname, '..', 'license.json');
fs.writeFileSync(outputPath, JSON.stringify(licenseFile, null, 2));

console.log('\n[OK] license.json created successfully.');
console.log('     Owner   :', payload.owner);
console.log('     Project :', payload.project);
console.log('     Issued  :', payload.issuedAt);
console.log('     Expires :', payload.expiresAt ?? 'Never');
console.log('\n  --> Copy license.json to the server root before starting the app.\n');
