#!/usr/bin/env node

/**
 * Migration script to hash existing plain text passwords in the database
 * Run this script once after updating the auth system
 *
 * Usage: npm run migrate-passwords
 */

const { PrismaClient } = require('../src/generated/prisma');
const bcrypt = require('bcryptjs');
const path = require('path');

// Load environment variables
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const prisma = new PrismaClient();

const SALT_ROUNDS = parseInt(process.env.BCRYPT_SALT_ROUNDS || '12');

async function hashPassword(password) {
  const salt = await bcrypt.genSalt(SALT_ROUNDS);
  return await bcrypt.hash(password, salt);
}

async function migratePasswords() {
  try {
    console.log('🔄 Starting password migration...');

    // Find all users
    const users = await prisma.user.findMany();

    if (users.length === 0) {
      console.log('ℹ️  No users found in database.');
      return;
    }

    console.log(`📊 Found ${users.length} users to migrate.`);

    let migrated = 0;
    let skipped = 0;

    for (const user of users) {
      try {
        // Check if password is already hashed (bcrypt hashes start with $2a$, $2b$, or $2y$)
        if (user.password.match(/^\$2[aby]\$/)) {
          console.log(`⏭️  Skipping user ${user.email} - already hashed`);
          skipped++;
          continue;
        }

        // Hash the plain text password
        const hashedPassword = await hashPassword(user.password);

        // Update the user with hashed password
        await prisma.user.update({
          where: { id: user.id },
          data: { password: hashedPassword },
        });

        console.log(`✅ Migrated password for user: ${user.email}`);
        migrated++;
      } catch (error) {
        console.error(
          `❌ Failed to migrate password for user ${user.email}:`,
          error.message,
        );
      }
    }

    console.log('\n📈 Migration Summary:');
    console.log(`   ✅ Migrated: ${migrated} users`);
    console.log(`   ⏭️  Skipped: ${skipped} users`);
    console.log(`   📊 Total: ${users.length} users`);

    if (migrated > 0) {
      console.log('\n🎉 Password migration completed successfully!');
      console.log('🔐 All passwords are now securely hashed.');
    } else {
      console.log(
        '\n✨ No migration needed - all passwords are already hashed.',
      );
    }
  } catch (error) {
    console.error('💥 Migration failed:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

// Create a default admin user if no users exist
async function createDefaultAdmin() {
  try {
    const userCount = await prisma.user.count();

    if (userCount === 0) {
      console.log('👤 No users found. Creating default admin user...');

      const defaultPassword = 'admin123';
      const hashedPassword = await hashPassword(defaultPassword);

      const admin = await prisma.user.create({
        data: {
          name: 'System Administrator',
          email: 'admin@vumi.com',
          password: hashedPassword,
          photo: '',
          role: 'ADMIN',
        },
      });

      console.log('✅ Default admin user created:');
      console.log(`   📧 Email: ${admin.email}`);
      console.log(`   🔑 Password: ${defaultPassword}`);
      console.log('   ⚠️  Please change this password after first login!');
    }
  } catch (error) {
    console.error('❌ Failed to create default admin:', error.message);
  }
}

// Main function
async function main() {
  console.log('🚀 Vumi Record System - Password Migration Tool');
  console.log('===============================================\n');

  await createDefaultAdmin();
  await migratePasswords();

  console.log('\n🏁 Migration process completed.');
}

// Run the migration
if (require.main === module) {
  main().catch(error => {
    console.error('💥 Unexpected error:', error);
    process.exit(1);
  });
}

module.exports = { migratePasswords, createDefaultAdmin };
