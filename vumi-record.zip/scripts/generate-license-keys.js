#!/usr/bin/env node
/**
 * generate-license-keys.js
 * ────────────────────────
 * Run this script ONCE to regenerate a fresh RSA-2048 key pair if you ever
 * need to rotate keys. After running, you MUST:
 *
 *  1. Replace the OWNER_PUBLIC_KEY constant in src/lib/license-check.ts
 *     with the newly generated owner.public.pem contents.
 *  2. Keep owner.private.pem in a safe location (NOT committed to git).
 *  3. Re-run `node scripts/sign-license.js` to create a new license.json.
 *  4. Rebuild and redeploy the application.
 *
 * Usage:
 *   node scripts/generate-license-keys.js
 */

const crypto = require('crypto');
const fs     = require('fs');
const path   = require('path');

const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
  modulusLength: 2048,
  publicKeyEncoding:  { type: 'spki',  format: 'pem' },
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
});

const root = path.join(__dirname, '..');
fs.writeFileSync(path.join(root, 'owner.private.pem'), privateKey, { mode: 0o600 });
fs.writeFileSync(path.join(root, 'owner.public.pem'),  publicKey);

console.log('\n[OK] Key pair generated:');
console.log('     owner.private.pem  ← KEEP THIS SECRET (never commit to git)');
console.log('     owner.public.pem   ← can be public\n');
console.log('[IMPORTANT] You must now:');
console.log('  1. Open src/lib/license-check.ts');
console.log('  2. Replace the OWNER_PUBLIC_KEY value with the new owner.public.pem contents.');
console.log('  3. Run: node scripts/sign-license.js');
console.log('  4. Rebuild and redeploy the app.\n');
